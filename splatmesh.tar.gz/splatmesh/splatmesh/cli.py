"""splatmesh — final USD asset: visual splat (payload) + physics collider.

Usage:
    splatmesh splat.usdz -o asset_finale.usdz
    splatmesh splat_clean.ply --visual splat.usdz -o asset_finale.usdz
    splatmesh splat.usdz --mode dynamic --scale 0.05 --label structure

The mesh is derived from the gaussians (see core.py). If the input is a .ply
and you also want the visual layer in the result, pass the .usdz via --visual.
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

import numpy as np
import trimesh

from .core import build_collider, log


def assemble_usd(collider: trimesh.Trimesh, out: Path, *,
                 ground: trimesh.Trimesh | None = None,
                 visual_usdz: Path | None = None, mode: str = "static",
                 scale_to_meters: float = 1.0, label: str | None = None,
                 preview_mesh: bool = True) -> Path:
    from pxr import Gf, Kind, Sdf, Usd, UsdGeom, UsdPhysics, UsdUtils, Vt

    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    usda = out.with_suffix(".usda")
    if usda.exists():
        usda.unlink()
    stage = Usd.Stage.CreateNew(str(usda))
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)
    world = UsdGeom.Xform.Define(stage, "/World")
    stage.SetDefaultPrim(world.GetPrim())
    Usd.ModelAPI(world.GetPrim()).SetKind(Kind.Tokens.component)
    if scale_to_meters != 1.0:
        UsdGeom.XformCommonAPI(world).SetScale(Gf.Vec3f(*([float(scale_to_meters)] * 3)))

    UsdGeom.Xform.Define(stage, "/World/Visual")
    if visual_usdz and Path(visual_usdz).exists():
        local = usda.parent / Path(visual_usdz).name
        if Path(visual_usdz).resolve() != local.resolve():
            shutil.copy2(visual_usdz, local)
        splat = UsdGeom.Xform.Define(stage, "/World/Visual/GaussianSplat")
        splat.GetPrim().GetPayloads().AddPayload(f"./{local.name}")
        log.info("Visual layer: %s (payload)", local.name)

    def author(path, m, purpose):
        um = UsdGeom.Mesh.Define(stage, path)
        um.GetPointsAttr().Set(Vt.Vec3fArray.FromNumpy(
            np.ascontiguousarray(m.vertices, dtype=np.float32)))
        um.GetFaceVertexCountsAttr().Set(Vt.IntArray.FromNumpy(
            np.full(len(m.faces), 3, dtype=np.int32)))
        um.GetFaceVertexIndicesAttr().Set(Vt.IntArray.FromNumpy(
            np.ascontiguousarray(m.faces.flatten(), dtype=np.int32)))
        um.GetSubdivisionSchemeAttr().Set(UsdGeom.Tokens.none)
        lo, hi = m.bounds.astype(float)
        um.GetExtentAttr().Set([Gf.Vec3f(*map(float, lo)), Gf.Vec3f(*map(float, hi))])
        UsdGeom.Imageable(um).GetPurposeAttr().Set(purpose)
        return um

    if preview_mesh:
        pv = author("/World/Visual/PreviewMesh", collider,
                    UsdGeom.Tokens.proxy if visual_usdz else UsdGeom.Tokens.default_)
        pv.GetDisplayColorAttr().Set([Gf.Vec3f(0.6, 0.6, 0.62)])

    col = author("/World/Physics/Collider", collider, UsdGeom.Tokens.guide)
    UsdGeom.Imageable(col).GetVisibilityAttr().Set(UsdGeom.Tokens.invisible)
    UsdPhysics.CollisionAPI.Apply(col.GetPrim())
    mc = UsdPhysics.MeshCollisionAPI.Apply(col.GetPrim())

    if ground is not None:
        if preview_mesh:
            gp = author("/World/Visual/GroundPreview", ground,
                        UsdGeom.Tokens.proxy if visual_usdz else UsdGeom.Tokens.default_)
            gp.GetDisplayColorAttr().Set([Gf.Vec3f(0.45, 0.62, 0.42)])
        gcol = author("/World/Physics/GroundCollider", ground, UsdGeom.Tokens.guide)
        UsdGeom.Imageable(gcol).GetVisibilityAttr().Set(UsdGeom.Tokens.invisible)
        UsdPhysics.CollisionAPI.Apply(gcol.GetPrim())
        gmc = UsdPhysics.MeshCollisionAPI.Apply(gcol.GetPrim())
        gmc.GetApproximationAttr().Set(UsdPhysics.Tokens.none)
        _lbl_ground(gcol.GetPrim())
        log.info("Ground layer: %d triangles (dedicated hole-free collider)", len(ground.faces))
    if mode == "dynamic":
        UsdPhysics.RigidBodyAPI.Apply(world.GetPrim())
        UsdPhysics.MassAPI.Apply(world.GetPrim())
        mc.GetApproximationAttr().Set(UsdPhysics.Tokens.convexDecomposition)
    else:
        mc.GetApproximationAttr().Set(UsdPhysics.Tokens.none)
        UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")

    if label:
        prim = world.GetPrim()
        try:
            from pxr import UsdSemantics
            UsdSemantics.LabelsAPI.Apply(prim, "class").GetLabelsAttr().Set([label])
        except ImportError:
            pass
        prim.AddAppliedSchema("SemanticsAPI:class_label")
        prim.CreateAttribute("semantic:class_label:params:semanticType",
                             Sdf.ValueTypeNames.String).Set("class")
        prim.CreateAttribute("semantic:class_label:params:semanticData",
                             Sdf.ValueTypeNames.String).Set(label)

    stage.Save()
    final = usda
    if out.suffix.lower() == ".usdz":
        ok = UsdUtils.CreateNewUsdzPackage(Sdf.AssetPath(str(usda)), str(out))
        if ok:
            final = out
        else:
            log.info("usdz packaging failed: delivering %s", usda)
    log.info("Final asset: %s", final)
    return final


def _lbl_ground(prim):
    from pxr import Sdf
    try:
        from pxr import UsdSemantics
        UsdSemantics.LabelsAPI.Apply(prim, "class").GetLabelsAttr().Set(["ground"])
    except ImportError:
        pass
    prim.AddAppliedSchema("SemanticsAPI:class_label")
    prim.CreateAttribute("semantic:class_label:params:semanticType",
                         Sdf.ValueTypeNames.String).Set("class")
    prim.CreateAttribute("semantic:class_label:params:semanticData",
                         Sdf.ValueTypeNames.String).Set("ground")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="splat (.usdz/.ply) -> collider mesh -> final USD/USDZ asset for Isaac Sim")
    ap.add_argument("input", help="Splat: .usdz (splat schema) or a clean 3DGS .ply")
    ap.add_argument("-o", "--output", help="Output .usdz/.usda (default: <input>_asset.usdz)")
    ap.add_argument("--visual", help="Splat USDZ to use as the visual layer "
                                     "(default: the input itself if it is .usdz)")
    ap.add_argument("--engine", choices=["auto", "voxel", "poisson"], default="auto",
                    help="auto = poisson if open3d is installed, else voxel")
    ap.add_argument("--voxel", type=float, default=None,
                    help="Voxel size in scene units (default: diagonal/grid-res)")
    ap.add_argument("--grid-res", type=int, default=300,
                    help="Grid resolution along the diagonal (default 300, max 448)")
    ap.add_argument("--iso", type=float, default=0.35,
                    help="Density threshold 0-1: low = closed/thick mesh, high = tight fit (default 0.35)")
    ap.add_argument("--poisson-depth", type=int, default=10)
    ap.add_argument("--target-faces", type=int, default=200000,
                    help="Collider triangle budget after decimation (default 200k)")
    ap.add_argument("--min-component-faces", type=int, default=300,
                    help="Disconnected components smaller than this are removed")
    ap.add_argument("--keep-components", type=int, default=0,
                    help="Keep only the N largest components (0 = all above threshold)")
    ap.add_argument("--mode", choices=["static", "dynamic"], default="static",
                    help="static = exact mesh collider; dynamic = rigid body + convex decomposition")
    ap.add_argument("--scale", type=float, default=1.0,
                    help="Scale-to-meters factor applied to the asset")
    ap.add_argument("--label", default=None, help="Semantic label (e.g. ground, structure)")
    ap.add_argument("--min-extent", type=float, default=0.0,
                    help="Remove components with a bbox diagonal below this size "
                         "(scene units): localized blobs go, extended geometry stays. 0=off")
    ap.add_argument("--max-hover", type=float, default=0.0,
                    help="Remove FLOATING components: max clearance above the ground (requires "
                         "--ground). 0=off")
    ap.add_argument("--hover-max-extent", type=float, default=0.0,
                    help="The floating filter only applies to components smaller than this "
                         "diagonal: extended elevated geometry is NEVER touched. "
                         "0 = applies to all")
    ap.add_argument("--save-mesh", help="Also save the collider mesh as .ply/.obj")
    ap.add_argument("--ground", action="store_true",
                    help="Add the GROUND layer: hole-free heightfield over the whole scene, "
                         "aggressively smoothed (general trend only)")
    ap.add_argument("--ground-smooth", type=float, default=4.0,
                    help="Ground smoothing strength, sigma in cells (default 4; 8+ = very smooth)")
    ap.add_argument("--ground-res", type=int, default=120,
                    help="Ground grid cells along the long side (default 120)")
    ap.add_argument("--ground-percentile", type=float, default=5.0,
                    help="Per-cell 'ground' height percentile (default 5)")
    ap.add_argument("--ground-object-size", type=float, default=0.0,
                    help="Object filter: localized bumps with a footprint up to this size "
                         "(scene units) are NOT terrain and get flattened. 0 = off")
    ap.add_argument("--ground-bump-thresh", type=float, default=0.0,
                    help="Minimum protrusion for a bump to count as an object "
                         "(0 = auto: 2%% of the height range)")
    ap.add_argument("--ground-robust-band", type=float, default=0.0,
                    help="Robust artifact filter: cells deviating from the reference terrain "
                         "beyond this tolerance (scene units, pits AND bumps from misaligned "
                         "cloud patches) are corrected. 0 = off")
    ap.add_argument("--save-ground", help="Also save the ground mesh as .ply/.obj")
    args = ap.parse_args()

    src = Path(args.input).expanduser()
    out = Path(args.output).expanduser() if args.output else src.with_name(src.stem + "_asset.usdz")
    visual = Path(args.visual).expanduser() if args.visual else (
        src if src.suffix.lower() == ".usdz" else None)

    mesh = build_collider(src, engine=args.engine, voxel=args.voxel,
                          grid_res=args.grid_res, iso=args.iso,
                          poisson_depth=args.poisson_depth,
                          min_component_faces=args.min_component_faces,
                          keep_components=args.keep_components,
                          target_faces=args.target_faces)
    ground = None
    if args.ground:
        from .core import build_ground, load_gaussians
        xyz, _, _ = load_gaussians(src)
        ground = build_ground(xyz, grid_res=args.ground_res,
                              percentile=args.ground_percentile,
                              smooth=args.ground_smooth,
                              object_size=args.ground_object_size,
                              bump_thresh=args.ground_bump_thresh,
                              robust_band=args.ground_robust_band)
        if args.save_ground:
            ground.export(args.save_ground)
    if args.min_extent > 0 or (args.max_hover > 0 and ground is not None):
        from .core import filter_components
        mesh = filter_components(mesh, min_extent=args.min_extent, ground=ground,
                                 max_hover=args.max_hover,
                                 hover_max_extent=args.hover_max_extent)
    if args.save_mesh:
        mesh.export(args.save_mesh)
        log.info("Mesh saved: %s", args.save_mesh)
    assemble_usd(mesh, out, ground=ground, visual_usdz=visual, mode=args.mode,
                 scale_to_meters=args.scale, label=args.label)
    return 0


if __name__ == "__main__":
    sys.exit(main())
