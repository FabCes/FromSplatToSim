"""splatmesh core — from the gaussian cloud to a clean collider mesh.

Two engines:
* "voxel"   (default): volumetric density from the gaussians (position, scale,
             opacity) -> marching cubes -> cleanup. No GPU, no open3d.
* "poisson" (optional): Poisson reconstruction via open3d, smoother
             surfaces; used only if open3d is installed.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import trimesh
from plyfile import PlyData

log = logging.getLogger("splatmesh")
if not log.handlers:
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(logging.Formatter("[%(asctime)s] %(message)s", "%H:%M:%S"))
    log.addHandler(h)
    log.setLevel(logging.INFO)


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


# ------------------------------------------------------------------ input
def load_gaussians(path: Path):
    """Return (xyz, scales_max, opacity 0-1) from a 3DGS .ply or a splat-schema
    .usdz (positions/scales/opacities attributes)."""
    path = Path(path)
    if path.suffix.lower() == ".ply":
        v = np.array(PlyData.read(str(path))["vertex"].data)
        xyz = np.vstack([v["x"], v["y"], v["z"]]).T.astype(np.float64)
        names = v.dtype.names
        if all(f"scale_{i}" in names for i in range(3)):
            sc = np.exp(np.vstack([v[f"scale_{i}"] for i in range(3)]).T.astype(np.float64))
            smax = sc.max(axis=1)
        else:
            smax = np.full(len(xyz), 0.01)
        op = sigmoid(np.asarray(v["opacity"], float)) if "opacity" in names else np.ones(len(xyz))
        return xyz, smax, op
    if path.suffix.lower() in (".usdz", ".usd", ".usda", ".usdc"):
        from pxr import Usd
        st = Usd.Stage.Open(str(path))
        for prim in st.Traverse():
            pos_attr = prim.GetAttribute("positions")
            if pos_attr and pos_attr.Get():
                xyz = np.asarray(pos_attr.Get(), dtype=np.float64)
                sc = prim.GetAttribute("scales")
                op = prim.GetAttribute("opacities")
                smax = (np.asarray(sc.Get(), float).max(axis=1)
                        if sc and sc.Get() is not None else np.full(len(xyz), 0.01))
                ops = (np.asarray(op.Get(), float).reshape(len(xyz), -1).max(axis=1)
                       if op and op.Get() is not None else np.ones(len(xyz)))
                # some variants store opacity as a logit
                if ops.max() > 1.001 or ops.min() < -0.001:
                    ops = sigmoid(ops)
                return xyz, smax, ops
        raise ValueError(f"No prim with a 'positions' attribute found in {path}")
    raise ValueError(f"Unsupported format: {path.suffix}")


# ------------------------------------------------------- voxel + marching
def mesh_from_gaussians_voxel(xyz, smax, op, *, voxel: float | None = None,
                              grid_res: int = 300, iso: float = 0.35, pad: int = 3,
                              max_grid: int = 448):
    """Grid density: each gaussian deposits a 3D kernel with radius ~ its scale,
    weighted by opacity. Marching cubes at the iso value.

    voxel: voxel size in scene units (None = auto, ~diagonal/grid_res)
    iso:   normalized density threshold (0-1): lower = thicker, more closed
           mesh; higher = tighter fit but possible holes
    """
    from scipy.ndimage import gaussian_filter
    from skimage.measure import marching_cubes

    lo, hi = xyz.min(0), xyz.max(0)
    diag = float(np.linalg.norm(hi - lo))
    if voxel is None:
        voxel = diag / float(grid_res)
    dims = np.ceil((hi - lo) / voxel).astype(int) + 2 * pad + 1
    if dims.max() > max_grid:                       # memory cap
        voxel = float((hi - lo).max() / (max_grid - 2 * pad - 1))
        dims = np.ceil((hi - lo) / voxel).astype(int) + 2 * pad + 1
    log.info("Grid %s (voxel %.4f)", dims.tolist(), voxel)

    grid = np.zeros(dims, dtype=np.float32)
    idx = np.floor((xyz - lo) / voxel).astype(int) + pad
    np.add.at(grid, (idx[:, 0], idx[:, 1], idx[:, 2]), op.astype(np.float32))

    # smoothing sigma tied to the median gaussian scale
    sigma_units = float(np.clip(np.median(smax), voxel, 4 * voxel))
    grid = gaussian_filter(grid, sigma=sigma_units / voxel)
    g99 = np.percentile(grid[grid > 0], 99) if (grid > 0).any() else 1.0
    grid = np.clip(grid / max(g99, 1e-9), 0, 1)

    verts, faces, _, _ = marching_cubes(grid, level=float(iso))
    verts = (verts - pad) * voxel + lo
    mesh = trimesh.Trimesh(vertices=verts, faces=faces, process=True)
    log.info("Marching cubes: %d faces", len(mesh.faces))
    return mesh


def mesh_from_gaussians_poisson(xyz, smax, op, *, depth: int = 10,
                                trim_quantile: float = 0.05):
    """Poisson via open3d (if installed): smoother surfaces."""
    import open3d as o3d
    pc = o3d.geometry.PointCloud()
    pc.points = o3d.utility.Vector3dVector(xyz)
    diag = float(np.linalg.norm(xyz.max(0) - xyz.min(0)))
    pc.estimate_normals(o3d.geometry.KDTreeSearchParamHybrid(radius=diag / 100, max_nn=30))
    pc.orient_normals_consistent_tangent_plane(30)
    m, dens = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(pc, depth=depth)
    dens = np.asarray(dens)
    m.remove_vertices_by_mask(dens < np.quantile(dens, trim_quantile))
    mesh = trimesh.Trimesh(np.asarray(m.vertices), np.asarray(m.triangles), process=True)
    log.info("Poisson: %d faces", len(mesh.faces))
    return mesh


# ---------------------------------------------------------------- cleanup
def clean_mesh(mesh: trimesh.Trimesh, *, min_component_faces: int = 300,
               keep_components: int = 0, target_faces: int = 200000,
               fill_holes: bool = True) -> trimesh.Trimesh:
    comps = mesh.split(only_watertight=False)
    if len(comps) > 1:
        comps = [m for m in comps if len(m.faces) >= min_component_faces]
        comps.sort(key=lambda m: -len(m.faces))
        if keep_components > 0:
            comps = comps[:keep_components]
        if comps:
            mesh = trimesh.util.concatenate(comps)
        log.info("Components kept: %d", len(comps))
    mesh.update_faces(mesh.nondegenerate_faces())
    mesh.remove_unreferenced_vertices()
    if fill_holes:
        trimesh.repair.fill_holes(mesh)
    if 0 < target_faces < len(mesh.faces):
        try:
            mesh = mesh.simplify_quadric_decimation(face_count=target_faces)
            log.info("Decimated to %d faces", len(mesh.faces))
        except BaseException as e:
            log.info("Decimation skipped (%s)", e)
    return mesh


def build_collider(src: Path, *, engine: str = "auto", voxel: float | None = None,
                   grid_res: int = 300, iso: float = 0.35, poisson_depth: int = 10,
                   min_component_faces: int = 300, keep_components: int = 0,
                   target_faces: int = 200000) -> trimesh.Trimesh:
    xyz, smax, op = load_gaussians(src)
    log.info("Loaded %d gaussians from %s", len(xyz), src)
    if engine == "auto":
        try:
            import open3d  # noqa: F401
            engine = "poisson"
        except ImportError:
            engine = "voxel"
        log.info("Selected engine: %s", engine)
    if engine == "poisson":
        mesh = mesh_from_gaussians_poisson(xyz, smax, op, depth=poisson_depth)
    else:
        mesh = mesh_from_gaussians_voxel(xyz, smax, op, voxel=voxel,
                                         grid_res=grid_res, iso=iso)
    return clean_mesh(mesh, min_component_faces=min_component_faces,
                      keep_components=keep_components, target_faces=target_faces)


# ------------------------------------------------------------------ ground
def build_ground(xyz, *, grid_res: int = 120, percentile: float = 5.0,
                 smooth: float = 4.0, margin: float = 0.0,
                 object_size: float = 0.0, bump_thresh: float = 0.0,
                 robust_band: float = 0.0):
    """Hole-free terrain heightfield over the full XY extent of the scene.

    - per XY cell, take a low percentile of heights (the ground, ignoring
      anything built/grown above it);
    - fill empty cells by interpolation (no holes by construction);
    - aggressive gaussian smoothing (sigma in cells) keeping only the
      general trend (slopes, hills).

    grid_res:    cells along the longest XY side (default 120)
    percentile:  "ground" height per cell (default 5; raise for noisy ground)
    smooth:      smoothing sigma in cells (default 4; higher = smoother)
    margin:      extra border extension in scene units
    object_size: OBJECT FILTER (scene units): localized bumps with a footprint
                 up to this size (small clutter, low vegetation) are NOT
                 terrain and are flattened to the surrounding ground level
                 via morphological opening. 0 = off. Extended relief (hills,
                 slopes) survives because it is larger than the window.
    bump_thresh: minimum protrusion (scene units) for a localized bump to be
                 treated as an object (0 = auto: 2% of the height range)
    robust_band: robust ARTIFACT FILTER (scene units): cells deviating from a
                 very smooth reference surface by more than this tolerance —
                 in BOTH directions: pits and bumps from misaligned cloud
                 patches — are corrected iteratively. 0 = off. Real terrain,
                 coherent at large scale, is untouched.
    """
    from scipy.ndimage import gaussian_filter, distance_transform_edt

    lo, hi = xyz.min(0), xyz.max(0)
    lo2, hi2 = lo[:2] - margin, hi[:2] + margin
    span = hi2 - lo2
    cell = float(span.max() / grid_res)
    nx, ny = (np.ceil(span / cell).astype(int) + 1)
    log.info("Ground: %dx%d grid (cell %.3f)", nx, ny, cell)

    ix = np.clip(((xyz[:, 0] - lo2[0]) / cell).astype(int), 0, nx - 1)
    iy = np.clip(((xyz[:, 1] - lo2[1]) / cell).astype(int), 0, ny - 1)
    flat = ix * ny + iy
    order = np.argsort(flat, kind="stable")
    flat_s, z_s = flat[order], xyz[order, 2]
    H = np.full(nx * ny, np.nan)
    starts = np.searchsorted(flat_s, np.arange(nx * ny))
    ends = np.searchsorted(flat_s, np.arange(nx * ny) + 1)
    occ = np.flatnonzero(ends > starts)
    for i in occ:
        H[i] = np.percentile(z_s[starts[i]:ends[i]], percentile)
    H = H.reshape(nx, ny)

    # fill empty cells with the nearest filled value
    if np.isnan(H).any():
        mask = np.isnan(H)
        idx = distance_transform_edt(mask, return_distances=False, return_indices=True)
        H = H[tuple(idx)]
        log.info("Ground: filled %d empty cells (%.0f%%)", mask.sum(),
                 100 * mask.sum() / H.size)

    # robust artifact filter: iterative rejection with a MASKED REFERENCE
    # (normalized convolution over good cells only): a misaligned cloud patch,
    # once excluded, can no longer pollute the terrain estimate. Handles pits
    # AND bumps, even extended ones.
    if robust_band and robust_band > 0:
        from scipy.ndimage import binary_dilation
        ref_sigma = max(6.0, 2.0 * float(smooth))
        good = np.ones_like(H, dtype=bool)
        prev_bad = 0
        for _ in range(10):
            w = good.astype(np.float32)
            ref = gaussian_filter(H * w, sigma=ref_sigma) / \
                (gaussian_filter(w, sigma=ref_sigma) + 1e-9)
            bad = np.abs(H - ref) > float(robust_band)
            # region growing: incoherent areas are eaten whole, not just eroded
            # at the edges
            bad = binary_dilation(bad, iterations=1) & \
                (np.abs(H - ref) > 0.5 * float(robust_band))
            good = ~bad
            if int(bad.sum()) == prev_bad:
                break
            prev_bad = int(bad.sum())
        n_bad = int((~good).sum())
        if n_bad:
            # fill artifact cells from the nearest good value, then smooth
            idx = distance_transform_edt(~good, return_distances=False,
                                         return_indices=True)
            H = np.where(good, H, H[tuple(idx)])
        log.info("Ground: artifact filter (band %.3f): corrected %d cells (%.0f%%)",
                 robust_band, n_bad, 100 * n_bad / H.size)

    # morphological object filter: flattens localized bumps, keeps extended
    # terrain. Standard DSM -> DTM technique.
    if object_size and object_size > 0:
        from scipy.ndimage import grey_opening
        win = max(3, int(np.ceil(object_size / cell)) | 1)   # odd, >= 3
        opened = grey_opening(H, size=(win, win))
        th = bump_thresh if bump_thresh > 0 else 0.02 * max(H.max() - H.min(), 1e-9)
        obj = (H - opened) > th
        H = np.where(obj, opened, H)
        log.info("Ground: object filter (window %d cells = %.2f units, thr %.3f): "
                 "flattened %d cells (%.0f%%)", win, win * cell, th,
                 int(obj.sum()), 100 * obj.sum() / H.size)

    # smoothing aggressivo: tiene l'andamento, elimina il dettaglio
    H = gaussian_filter(H, sigma=float(smooth))

    # regular grid mesh (no holes by construction)
    xs = lo2[0] + np.arange(nx) * cell
    ys = lo2[1] + np.arange(ny) * cell
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    verts = np.c_[X.ravel(), Y.ravel(), H.ravel()]
    ii, jj = np.meshgrid(np.arange(nx - 1), np.arange(ny - 1), indexing="ij")
    a = (ii * ny + jj).ravel(); b = a + ny; c = a + 1; d = b + 1
    faces = np.r_[np.c_[a, b, c], np.c_[c, b, d]]
    ground = trimesh.Trimesh(vertices=verts, faces=faces, process=False)
    log.info("Ground mesh: %d triangles, heights %.2f..%.2f",
             len(ground.faces), H.min(), H.max())
    return ground


# ------------------------------------------------------ component filters
def filter_components(mesh: trimesh.Trimesh, *, min_extent: float = 0.0,
                      ground: "trimesh.Trimesh | None" = None,
                      max_hover: float = 0.0,
                      hover_max_extent: float = 0.0) -> trimesh.Trimesh:
    """Per-connected-component artifact filters for the structure collider.

    min_extent: minimum physical size (bbox diagonal, scene units): localized
                blobs vanish regardless of face count. 0 = off.
    ground + max_hover: FLOATING filter: components whose lowest point sits
                more than max_hover above the terrain at that XY are suspended
                artifacts. 0 = off.
    hover_max_extent: the floating filter only applies to components with a
                bbox diagonal below this threshold — extended elevated
                geometry (canopies, cables, elevated structures) is preserved
                even if it does not touch the ground: an artifact is suspended
                AND localized. 0 = applies to all components.
    """
    comps = mesh.split(only_watertight=False)
    if len(comps) <= 1 and min_extent <= 0:
        return mesh
    gv = ground.vertices if ground is not None else None
    kept, dropped_ext, dropped_fly = [], 0, 0
    for c in comps:
        if min_extent > 0:
            diag = float(np.linalg.norm(c.bounds[1] - c.bounds[0]))
            if diag < min_extent:
                dropped_ext += 1
                continue
        if gv is not None and max_hover > 0:
            if hover_max_extent > 0:
                diag_c = float(np.linalg.norm(c.bounds[1] - c.bounds[0]))
                if diag_c >= hover_max_extent:
                    kept.append(c)      # extended (row/canopy): never removed as floating
                    continue
            i = int(np.argmin(c.vertices[:, 2]))
            px, py, pz = c.vertices[i]
            j = np.argmin((gv[:, 0] - px) ** 2 + (gv[:, 1] - py) ** 2)
            if pz - gv[j, 2] > max_hover:
                dropped_fly += 1
                continue
        kept.append(c)
    log.info("Components: kept %d, removed %d below extent %.2f, "
             "%d removed as floating (> %.2f above ground)",
             len(kept), dropped_ext, min_extent, dropped_fly, max_hover)
    if not kept:
        log.info("WARNING: filters too strict, keeping the largest component")
        kept = [max(comps, key=lambda m: len(m.faces))]
    return trimesh.util.concatenate(kept) if len(kept) > 1 else kept[0]
