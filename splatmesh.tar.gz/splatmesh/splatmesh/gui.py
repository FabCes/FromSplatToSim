"""splatmesh GUI — splat → collider mesh → final USD/USDZ asset.

    splatmesh-gui            # http://localhost:8082
"""
from __future__ import annotations

import threading
from pathlib import Path

import numpy as np
import yaml
from nicegui import ui

from .core import build_collider, build_ground, filter_components, load_gaussians, log
from .cli import assemble_usd

CONFIG_FILE = Path.home() / ".config/splatmesh.yaml"
state: dict = {"mesh": None, "ground": None, "busy": False}


def load_settings() -> dict:
    if CONFIG_FILE.exists():
        return yaml.safe_load(CONFIG_FILE.read_text()) or {}
    return {}


def save_settings(**kw) -> None:
    s = load_settings()
    s.update({k: v for k, v in kw.items() if v})
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(yaml.safe_dump(s))


def main(port: int = 8082) -> None:
    settings = load_settings()

    @ui.page("/")
    def index():
        ui.markdown("## 🧱 splatmesh — splat → collider mesh → final USD asset")
        ui.markdown("Derives the mesh directly from the gaussians (no GPU, no retraining) and "
                    "assembles the two-layer Isaac Sim asset: visual splat + invisible, "
                    "aligned physics collider.")

        # ---------------------------------------------------- input
        with ui.card().classes("w-full"):
            ui.label("1 · Input").classes("text-lg font-bold")
            src_in = ui.input("Mesh source: clean .ply (recommended) or splat .usdz",
                              value=settings.get("src", "")).classes("w-full")
            vis_in = ui.input("Visual layer .usdz (empty = use the source if it is .usdz)",
                              value=settings.get("visual", "")).classes("w-full")
            out_in = ui.input("Final output (.usdz)",
                              value=settings.get("out", str(Path.home() / "splatmesh_out/asset.usdz"))
                              ).classes("w-full")
            ui.markdown("*Tip: source = the `_clean.ply` from splatlite (more faithful geometry), "
                        "visual = the `.usdz` exported next to it.*").classes("text-xs")

        # ------------------------------------------------- meshing
        with ui.card().classes("w-full"):
            ui.label("2 · Mesh parameters").classes("text-lg font-bold")

            engine = ui.select({"auto": "auto (poisson if open3d is installed, else voxel)",
                                "voxel": "voxel + marching cubes (always available)",
                                "poisson": "poisson (requires open3d, smoother surfaces)"},
                               value="auto", label="Engine").classes("w-96")

            with ui.row().classes("items-center"):
                iso = ui.slider(min=0.1, max=0.7, step=0.01, value=0.35).classes("w-64")
                ui.label().bind_text_from(iso, "value", lambda v: f"Iso threshold: {v:.2f}")
            ui.markdown("*Voxel engine only. Threshold on the gaussian density (0-1): **lower "
                        "= thicker, more closed mesh** (robust colliders, recommended for "
                        "thin structures), higher = tighter surface fit but with "
                        "possible holes.*").classes("text-xs")

            with ui.row().classes("items-center"):
                res = ui.slider(min=100, max=448, step=10, value=300).classes("w-64")
                ui.label().bind_text_from(res, "value", lambda v: f"Grid resolution: ~{int(v)}")
            ui.markdown("*Voxel engine only. Voxels along the scene diagonal: "
                        "higher = more detail (thin elements) but more RAM and more raw "
                        "triangles. 300 is a good default; 448 for fine structures.*").classes("text-xs")

            with ui.row().classes("items-center"):
                tgt = ui.number("Collider triangle budget", value=200000, step=10000)
                minc = ui.number("Min faces per component", value=300, step=50)
                keepc = ui.number("Keep only N components (0=all)", value=0, step=1)
            ui.markdown("*The triangle budget is the final decimation target (PhysX handles "
                        "100-300k fine for static scenes). Disconnected components smaller "
                        "than the threshold are removed: residual floaters die here — if "
                        "you only want the main structure, set \"Keep only\" to 1-3.*"
                        ).classes("text-xs")

            mesh_lbl = ui.markdown("")
            logbox = ui.log(max_lines=200).classes("w-full h-32 font-mono text-xs")

            def do_mesh():
                if state["busy"]:
                    return ui.notify("Operation in progress", type="warning")
                src = Path(src_in.value).expanduser()
                if not src.exists():
                    return ui.notify("Source not found", type="negative")
                save_settings(src=str(src), visual=vis_in.value, out=out_in.value)
                state["busy"] = True
                mesh_lbl.set_content("⏳ Generating mesh...")

                old = log.info
                def tee(msg, *a):
                    old(msg, *a)
                    try: logbox.push(msg % a if a else str(msg))
                    except Exception: pass

                def worker():
                    log.info = tee
                    try:
                        mesh = build_collider(
                            src, engine=engine.value, iso=float(iso.value),
                            grid_res=int(res.value),
                            target_faces=int(tgt.value),
                            min_component_faces=int(minc.value),
                            keep_components=int(keepc.value))
                        state["mesh"] = mesh
                        lo, hi = mesh.bounds
                        mesh_lbl.set_content(
                            f"✅ **Mesh ready: {len(mesh.faces)} triangles**, bounds "
                            f"({lo[0]:.1f}, {lo[1]:.1f}, {lo[2]:.1f}) → ({hi[0]:.1f}, {hi[1]:.1f}, "
                            f"{hi[2]:.1f}). Check the preview, then assemble the asset.")
                        draw_preview()
                    except Exception as e:
                        mesh_lbl.set_content(f"❌ {e}")
                    finally:
                        log.info = old
                        state["busy"] = False
                threading.Thread(target=worker, daemon=True).start()

            ui.button("Generate mesh", icon="grid_on", on_click=do_mesh).props("color=primary")

        # -------------------------------------------------- ground
        with ui.card().classes("w-full"):
            ui.label("2b · Ground (optional)").classes("text-lg font-bold")
            ui.markdown("*Generates a dedicated GROUND mesh: a regular heightfield covering "
                        "the full XY extent of the scene — **hole-free by construction** — "
                        "built from the lowest points of each cell (ignores anything built "
                        "or grown above) and aggressively smoothed to keep only the general "
                        "terrain trend (slopes, hills). Requires the real ground to be visible "
                        "in the capture. Enters the asset as a separate collider labeled "
                        "`ground`.*").classes("text-xs")
            ground_on = ui.switch("Add ground layer")
            with ui.row().classes("items-center"):
                g_smooth = ui.slider(min=1, max=15, step=0.5, value=4).classes("w-64")
                ui.label().bind_text_from(g_smooth, "value",
                                          lambda v: f"Smoothing (σ in cells): {v:.1f}")
            ui.markdown("*Smoothing strength: 2-3 keeps local undulations, 4-6 the general "
                        "profile (default), 8-15 nearly a tilted plane following only the "
                        "average slope.*").classes("text-xs")
            with ui.row().classes("items-center"):
                g_obj = ui.slider(min=0.0, max=5.0, step=0.1, value=0.0).classes("w-64")
                ui.label().bind_text_from(g_obj, "value",
                                          lambda v: f"Max object size: {v:.1f} (0 = off)")
            ui.markdown("*Object filter: **localized** bumps with a footprint up to this "
                        "size (scene units — small clutter, debris) are not terrain and "
                        "get flattened to the surrounding ground level. **Extended** relief "
                        "(hills, slopes) stays intact because it is larger than the window. "
                        "Use the scene bounds to calibrate: e.g. if typical clutter is ~1/20 "
                        "of the scene, set that value.*").classes("text-xs")
            with ui.row().classes("items-center"):
                g_band = ui.slider(min=0.0, max=2.0, step=0.05, value=0.0).classes("w-64")
                ui.label().bind_text_from(g_band, "value",
                                          lambda v: f"Artifact tolerance: {v:.2f} (0 = off)")
            ui.markdown("*Robust filter for **misaligned clouds**: estimates a reference terrain "
                        "from coherent areas only and corrects cells deviating beyond the "
                        "tolerance — both pits and bumps, even extended ones (incoherent areas "
                        "are consumed whole, not just at the edges). Set the tolerance "
                        "≈ to the artifact amplitude you observe: lower = more aggressive. "
                        "Real terrain, coherent at large scale, is untouched.*").classes("text-xs")
            with ui.row().classes("items-center"):
                g_res = ui.slider(min=40, max=250, step=10, value=120).classes("w-64")
                ui.label().bind_text_from(g_res, "value", lambda v: f"Grid resolution: {int(v)}")
                g_perc = ui.number("Ground percentile", value=5.0, step=1.0)
            ui.markdown("*Percentile: which per-cell height counts as ground — 5 by default; raise it "
                        "(10-20) if the reconstructed terrain looks noisy or pitted downward.*"
                        ).classes("text-xs")
            ground_lbl = ui.markdown("")

            def do_ground():
                src = Path(src_in.value).expanduser()
                if not src.exists():
                    return ui.notify("Source not found", type="negative")
                ground_lbl.set_content("⏳ Generating ground...")

                def worker():
                    try:
                        xyz, _, _ = load_gaussians(src)
                        g = build_ground(xyz, grid_res=int(g_res.value),
                                         percentile=float(g_perc.value),
                                         smooth=float(g_smooth.value),
                                         object_size=float(g_obj.value),
                                         robust_band=float(g_band.value))
                        state["ground"] = g
                        lo, hi = g.vertices[:, 2].min(), g.vertices[:, 2].max()
                        ground_lbl.set_content(
                            f"✅ **Ground: {len(g.faces)} triangles**, heights {lo:.2f} → {hi:.2f} "
                            f"(range {hi - lo:.2f}). Check the preview (in green).")
                        draw_preview()
                    except Exception as e:
                        ground_lbl.set_content(f"❌ {e}")
                threading.Thread(target=worker, daemon=True).start()

            ui.button("Generate ground", icon="terrain", on_click=do_ground)

        # ----------------------------------------- component filters
        with ui.card().classes("w-full"):
            ui.label("2c · Structure artifact filter").classes("text-lg font-bold")
            ui.markdown("*Cleans disconnected components of the structure collider. Designed NOT "
                        "to touch elevated geometry you want as a collider: an extended canopy is "
                        "suspended but **extended**, an artifact is suspended and **localized**.*").classes("text-xs")
            with ui.row().classes("items-center"):
                f_ext = ui.slider(min=0.0, max=3.0, step=0.05, value=0.0).classes("w-64")
                ui.label().bind_text_from(f_ext, "value",
                                          lambda v: f"Min component extent: {v:.2f} (0=off)")
            ui.markdown("*Components with a bbox diagonal below this size (scene units) "
                        "vanish: localized blobs go, extended rows and canopies "
                        "stay.*").classes("text-xs")
            with ui.row().classes("items-center"):
                f_hov = ui.slider(min=0.0, max=2.0, step=0.05, value=0.0).classes("w-64")
                ui.label().bind_text_from(f_hov, "value",
                                          lambda v: f"Max hover above ground: {v:.2f} (0=off)")
                f_hme = ui.number("only for components < (diag)", value=2.0, step=0.5)
            ui.markdown("*Removes components floating more than the given clearance above the "
                        "ground (requires the ground from 2b). The field on the right restricts "
                        "the filter to small components only: **extended suspended geometry is "
                        "never removed**, even if it does not touch the ground. Set the threshold "
                        "above your largest artifact and below your smallest extended element.*"
                        ).classes("text-xs")
            filt_lbl = ui.markdown("")

            def do_filter():
                if state["mesh"] is None:
                    return ui.notify("Generate the mesh first", type="warning")
                if float(f_hov.value) > 0 and state.get("ground") is None:
                    return ui.notify("The floating filter requires the ground (2b)", type="warning")
                try:
                    n0 = len(state["mesh"].split(only_watertight=False))
                    state["mesh"] = filter_components(
                        state["mesh"], min_extent=float(f_ext.value),
                        ground=state.get("ground"), max_hover=float(f_hov.value),
                        hover_max_extent=float(f_hme.value))
                    n1 = len(state["mesh"].split(only_watertight=False))
                    filt_lbl.set_content(f"✅ Components: {n0} → {n1}. Check the preview; "
                                         "if too much was removed, regenerate the mesh (2) and retry "
                                         "with lower thresholds.")
                    draw_preview()
                except Exception as e:
                    filt_lbl.set_content(f"❌ {e}")

            ui.button("Apply component filters", icon="filter_alt",
                      on_click=do_filter).props("color=primary")

        # ------------------------------------------------- preview
        with ui.card().classes("w-full"):
            ui.label("3 · Collider preview").classes("text-lg font-bold")
            ui.markdown("*The mesh PhysX will see. Drag to orbit, scroll to zoom. "
                        "Large holes or missing parts → lower the iso threshold or raise the "
                        "resolution and regenerate.*").classes("text-xs")
            preview_holder = ui.column().classes("w-full")

            def draw_preview():
                m = state["mesh"]
                g = state.get("ground")
                if m is None and g is None:
                    return
                import trimesh as _tm
                parts = []
                if m is not None:
                    pm = m
                    if len(pm.faces) > 80000:
                        try:
                            pm = pm.simplify_quadric_decimation(face_count=80000)
                        except BaseException:
                            pass
                    pm = pm.copy()
                    pm.visual.vertex_colors = [160, 160, 165, 255]
                    parts.append(pm)
                if g is not None and ground_on.value:
                    gg = g.copy()
                    gg.visual.vertex_colors = [110, 160, 105, 255]
                    parts.append(gg)
                pm = _tm.util.concatenate(parts) if len(parts) > 1 else parts[0]
                glb_dir = Path.home() / ".cache/splatmesh"
                glb_dir.mkdir(parents=True, exist_ok=True)
                glb = glb_dir / "preview.glb"
                pm.export(glb)
                from nicegui import app
                app.add_static_files("/smprev", str(glb_dir))
                import time
                preview_holder.clear()
                with preview_holder:
                    with ui.scene(width=900, height=500).classes("w-full") as sc:
                        sc.gltf(f"/smprev/preview.glb?t={int(time.time())}")

            ui.button("Refresh preview", icon="visibility", on_click=draw_preview)

        # -------------------------------------------------- export
        with ui.card().classes("w-full"):
            ui.label("4 · Assemble USD asset").classes("text-lg font-bold")
            mode = ui.select({"static": "Static environment (exact mesh collider + PhysicsScene)",
                              "dynamic": "Dynamic object (rigid body + convex decomposition)"},
                             value="static", label="Asset type").classes("w-96")
            scale = ui.number("Scale → meters (real ÷ measured in scene units)", value=1.0, step=0.01)
            label = ui.input("Semantic label (e.g. ground, structure)", value="")
            ui.markdown("*The COLMAP scene is not metric: measure a known distance "
                        "in the units of the bounds above and set the ratio. "
                        "In Isaac Sim: new stage → drag the asset in as a reference.*").classes("text-xs")
            export_lbl = ui.markdown("")

            def do_export():
                if state["mesh"] is None:
                    return ui.notify("Generate the mesh first", type="warning")
                out = Path(out_in.value).expanduser()
                vis = Path(vis_in.value).expanduser() if vis_in.value else None
                if vis is None:
                    src = Path(src_in.value).expanduser()
                    vis = src if src.suffix.lower() == ".usdz" else None
                export_lbl.set_content("⏳ Assembling the asset...")

                def worker():
                    try:
                        g = state.get("ground") if ground_on.value else None
                        final = assemble_usd(state["mesh"], out, ground=g, visual_usdz=vis,
                                             mode=mode.value, scale_to_meters=float(scale.value),
                                             label=label.value or None)
                        vis_msg = f" + visual splat `{vis.name}`" if vis else " (mesh only: no visual provided)"
                        export_lbl.set_content(f"✅ **Final asset: `{final}`**{vis_msg}")
                    except Exception as e:
                        export_lbl.set_content(f"❌ {e}")
                threading.Thread(target=worker, daemon=True).start()

            ui.button("Assemble asset", icon="rocket", on_click=do_export).props("color=primary")

    ui.run(port=port, title="splatmesh", reload=False, show=False)


def cli():
    import argparse
    ap = argparse.ArgumentParser(description="splatmesh GUI")
    ap.add_argument("--port", type=int, default=8082)
    main(port=ap.parse_args().port)


if __name__ in {"__main__", "__mp_main__"}:
    main()
