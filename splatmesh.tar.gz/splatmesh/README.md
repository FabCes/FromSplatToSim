# splatmesh

**Splat (.usdz or .ply) → collider mesh + optional hole-free ground → final two-layer USD/USDZ asset for Isaac Sim.**

Closes the pipeline after splatlite: derives a physics mesh directly from the gaussians (no GPU, no retraining) and assembles:
```
/World  (Z-up, meters)
├── Visual/GaussianSplat    ← your visual .usdz (payload)
├── Visual/PreviewMesh      ← proxy mesh (preview / RTX lidar)
├── Visual/GroundPreview    ← optional, green
├── Physics/Collider        ← invisible UsdPhysics mesh
└── Physics/GroundCollider  ← optional hole-free terrain, labeled "ground"
```

## Install
```bash
tar xzf splatmesh.tar.gz && cd splatmesh
python3 -m venv .venv && source .venv/bin/activate
pip install -e .                       # voxel engine (always available)
# optional smoother Poisson engine:  pip install -e ".[poisson]"
splatmesh-gui                          # GUI at http://localhost:8082
```

## CLI
```bash
splatmesh scene_clean.ply --visual scene.usdz -o scene_asset.usdz \
  --ground --ground-smooth 5 --ground-robust-band 0.25 --ground-object-size 1.0 \
  --min-extent 0.5 --max-hover 0.3 --hover-max-extent 3.0 \
  --mode static --scale 0.05 --label structure
```
Run `splatmesh -h` for every flag; the project README explains what each parameter does and when to change it.
