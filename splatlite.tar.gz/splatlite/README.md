# splatlite

**Existing COLMAP folder → gaussian splat → orientation + parametric cleanup → USDZ (visual layer only).**

Standalone lightweight GUI that drives an EXISTING 3dgrut installation (path set in the GUI, remembered in `~/.config/splatlite.yaml`, or env `SPLATLITE_3DGRUT`). No physics, no meshing — the ideal companion when you already have poses and just need a clean, well-oriented splat.

## Install
```bash
tar xzf splatlite.tar.gz && cd splatlite
python3 -m venv .venv && source .venv/bin/activate
pip install -e .
splatlite                 # GUI at http://localhost:8081
```

## Workflow (GUI sections)
0. **Configuration** — path to your 3dgrut checkout (must contain `train.py`).
1. **Input** — train from a COLMAP folder (`images/` + `sparse/0/`) with live logs, or load an already-trained `.ply`.
2. **Orientation** — auto-level via RANSAC dominant plane, PCA axes, manual XYZ degrees, ground-to-z=0. Applied to positions and per-gaussian quaternions.
3. **Cleanup** — four explained filters: min opacity (training dust), max gaussian scale (sky/halo blobs), statistical outlier removal (floaters, k/σ), axis-aligned crop box with robust fit-to-bounds.
4. **Preview** — colored kept vs gray removed centers, red crop box, orbit/zoom.
5. **USDZ export** — saves the clean `.ply` and converts it to the Isaac Sim splat schema. The bundled converter drives the 3dgrut API with camera export disabled, so it works from a bare PLY.

The clean `.ply` it writes next to the `.usdz` is the recommended input for **splatmesh** (colliders).
