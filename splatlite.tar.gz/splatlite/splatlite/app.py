"""splatlite — COLMAP → gaussian splat → cleanup → USDZ (Isaac Sim).

Standalone lightweight app: uses an EXISTING 3dgrut installation (no
automatic cloning) and a ready COLMAP folder. Visual splat only: no mesh,
no physics.

    splatlite            # GUI at http://localhost:8081
    splatlite --port N   # different port

The 3dgrut path is set in the GUI (or env SPLATLITE_3DGRUT) and remembered
in ~/.config/splatlite.yaml.
"""
from __future__ import annotations

import glob
import os
import subprocess
import threading
from pathlib import Path

import numpy as np
import yaml
from nicegui import ui
from plyfile import PlyData, PlyElement

CONFIG_FILE = Path.home() / ".config/splatlite.yaml"
SH_C0 = 0.28209479177387814

state: dict = {"v": None, "xyz": None, "rgb": None, "keep": None, "busy": False}


# ------------------------------------------------------------ persistence
def load_settings() -> dict:
    if CONFIG_FILE.exists():
        return yaml.safe_load(CONFIG_FILE.read_text()) or {}
    return {}


def save_settings(**kw) -> None:
    s = load_settings()
    s.update({k: v for k, v in kw.items() if v})
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(yaml.safe_dump(s))


# ------------------------------------------------------------------ core
def load_gaussians(ply_path: Path):
    import numpy as _np
    v = _np.array(PlyData.read(str(ply_path))["vertex"].data)
    xyz = np.vstack([v["x"], v["y"], v["z"]]).T.astype(np.float64)
    if all(f"f_dc_{i}" in v.dtype.names for i in range(3)):
        dc = np.vstack([v[f"f_dc_{i}"] for i in range(3)]).T
        rgb = np.clip(0.5 + SH_C0 * dc, 0, 1)
    else:
        rgb = np.full((len(xyz), 3), 0.6)
    return v, xyz, rgb


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def statistical_inliers(pts: np.ndarray, k: int, n_std: float) -> np.ndarray:
    from scipy.spatial import cKDTree
    d, _ = cKDTree(pts).query(pts, k=k + 1)
    mean_d = d[:, 1:].mean(axis=1)
    return np.flatnonzero(mean_d <= mean_d.mean() + n_std * mean_d.std())


def compute_keep(v, xyz, *, min_opacity, max_scale, out_k, out_std, crop):
    keep = np.ones(len(xyz), dtype=bool)
    names = v.dtype.names
    if "opacity" in names and min_opacity > 0:
        keep &= sigmoid(np.asarray(v["opacity"], float)) >= min_opacity
    if all(f"scale_{i}" in names for i in range(3)) and max_scale > 0:
        s = np.exp(np.vstack([v[f"scale_{i}"] for i in range(3)]).T.astype(float))
        keep &= s.max(axis=1) <= max_scale
    if crop is not None:
        c, h = np.asarray(crop[0], float), np.asarray(crop[1], float) / 2.0
        keep &= np.all(np.abs(xyz - c) <= h, axis=1)
    if out_k > 0 and keep.sum() > out_k + 1:
        idx = np.flatnonzero(keep)
        m = np.zeros(len(xyz), bool)
        m[idx[statistical_inliers(xyz[idx], int(out_k), float(out_std))]] = True
        keep = m
    return keep


# ------------------------------------------------------------ orientation
def rot_matrix_xyz(rx, ry, rz):
    """Rotation matrix from degrees (X, then Y, then Z)."""
    a, b, c = np.radians([rx, ry, rz])
    Rx = np.array([[1, 0, 0], [0, np.cos(a), -np.sin(a)], [0, np.sin(a), np.cos(a)]])
    Ry = np.array([[np.cos(b), 0, np.sin(b)], [0, 1, 0], [-np.sin(b), 0, np.cos(b)]])
    Rz = np.array([[np.cos(c), -np.sin(c), 0], [np.sin(c), np.cos(c), 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def mat_to_quat(R):
    """3x3 matrix -> quaternion (w, x, y, z)."""
    w = np.sqrt(max(0.0, 1 + R[0, 0] + R[1, 1] + R[2, 2])) / 2
    if w > 1e-8:
        x = (R[2, 1] - R[1, 2]) / (4 * w)
        y = (R[0, 2] - R[2, 0]) / (4 * w)
        z = (R[1, 0] - R[0, 1]) / (4 * w)
    else:
        x, y, z, w = 0.0, 0.0, 0.0, 1.0
    return np.array([w, x, y, z])


def quat_mul(q1, q2):
    """Prodotto di quaternioni (w,x,y,z); q1 (4,), q2 (N,4)."""
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2[..., 0], q2[..., 1], q2[..., 2], q2[..., 3]
    return np.stack([
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2], axis=-1)


def apply_rotation(v, xyz, R, pivot=None):
    """Rotate gaussian positions and quaternions IN PLACE around the pivot."""
    if pivot is None:
        pivot = xyz.mean(0)
    new_xyz = (xyz - pivot) @ R.T + pivot
    v["x"], v["y"], v["z"] = (new_xyz[:, 0].astype(np.float32),
                              new_xyz[:, 1].astype(np.float32),
                              new_xyz[:, 2].astype(np.float32))
    names = v.dtype.names
    if all(f"rot_{i}" in names for i in range(4)):
        q = np.vstack([v[f"rot_{i}"] for i in range(4)]).T.astype(np.float64)
        qn = quat_mul(mat_to_quat(R), q)
        qn /= np.linalg.norm(qn, axis=1, keepdims=True) + 1e-12
        for i in range(4):
            v[f"rot_{i}"] = qn[:, i].astype(np.float32)
    return new_xyz


def align_normal_to_z(normal):
    """Minimal rotation taking 'normal' to +Z."""
    n = normal / (np.linalg.norm(normal) + 1e-12)
    z = np.array([0.0, 0.0, 1.0])
    vx = np.cross(n, z); c = float(np.dot(n, z)); s = np.linalg.norm(vx)
    if s < 1e-9:
        return np.eye(3) if c > 0 else np.diag([1.0, -1.0, -1.0])
    vx = vx / s
    K = np.array([[0, -vx[2], vx[1]], [vx[2], 0, -vx[0]], [-vx[1], vx[0], 0]])
    ang = np.arctan2(s, c)
    return np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * (K @ K)


def ransac_ground(xyz, iters=300, rel_thresh=0.01, seed=0):
    """Piano dominante via RANSAC -> (normale verso la scena, punto, inlier)."""
    rng = np.random.default_rng(seed)
    diag = np.linalg.norm(xyz.max(0) - xyz.min(0))
    th = rel_thresh * diag
    sub = xyz[rng.choice(len(xyz), min(len(xyz), 30000), replace=False)]
    best_n, best_p, best_cnt = None, None, -1
    for _ in range(iters):
        p3 = sub[rng.choice(len(sub), 3, replace=False)]
        n = np.cross(p3[1] - p3[0], p3[2] - p3[0])
        ln = np.linalg.norm(n)
        if ln < 1e-9:
            continue
        n = n / ln
        d = np.abs((sub - p3[0]) @ n)
        cnt = int((d < th).sum())
        if cnt > best_cnt:
            best_n, best_p, best_cnt = n, p3[0], cnt
    if np.median((sub - best_p) @ best_n) < 0:
        best_n = -best_n
    return best_n, best_p, best_cnt


def pca_up(xyz):
    """Asse di minima varianza (candidato 'up' per scene distese)."""
    sub = xyz - xyz.mean(0)
    sel = sub[np.random.default_rng(0).choice(len(sub), min(len(sub), 50000), replace=False)]
    w, V = np.linalg.eigh(np.cov(sel.T))
    n = V[:, 0]
    if np.median(sub @ n) < 0:
        n = -n
    return n


def save_filtered(v, keep, dst: Path):
    PlyData([PlyElement.describe(v[keep], "vertex")]).write(str(dst))


# --------------------------------------------------------- external tools
def gdrut_env(repo: Path) -> dict:
    """PATH with the 3dgrut venv (slangc) and the most recent CUDA toolkit."""
    env = dict(os.environ)
    path = env.get("PATH", "")
    if (repo / ".venv/bin").exists():
        path = f"{repo / '.venv/bin'}:{path}"
        env["VIRTUAL_ENV"] = str(repo / ".venv")
    for d in sorted(glob.glob("/usr/local/cuda-13*"), reverse=True) + \
            sorted(glob.glob("/usr/local/cuda-12*"), reverse=True) + ["/usr/local/cuda"]:
        if (Path(d) / "bin/nvcc").exists():
            path = f"{Path(d) / 'bin'}:{path}"
            env["CUDA_HOME"] = d
            env["LD_LIBRARY_PATH"] = f"{Path(d) / 'lib64'}:{env.get('LD_LIBRARY_PATH', '')}"
            break
    env["PATH"] = path
    return env


def gdrut_python(repo: Path) -> str:
    for c in (repo / ".venv/bin/python", repo / "venv/bin/python"):
        if c.exists():
            return str(c)
    return "python3"


def stream(cmd, cwd, env, on_line):
    proc = subprocess.Popen([str(c) for c in cmd], cwd=str(cwd), env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, bufsize=1)
    for line in proc.stdout:
        on_line(line.rstrip())
    if proc.wait() != 0:
        raise RuntimeError(f"exit {proc.returncode}: {' '.join(map(str, cmd))}")


# -------------------------------------------------------------------- GUI
def main(port: int = 8081) -> None:
    settings = load_settings()

    @ui.page("/")
    def index():
        ui.markdown("## 🧹 splatlite — COLMAP → clean splat → USDZ")
        ui.markdown("Visual layer only: optional training, cleanup with explained parameters, "
                    "before/after 3D preview, USDZ export for Isaac Sim. No mesh/physics.")

        # -------------------------------------------------- setup
        with ui.card().classes("w-full"):
            ui.label("0 · Configuration").classes("text-lg font-bold")
            g3_path = ui.input("3dgrut installation folder",
                               value=settings.get("gdrut", os.environ.get("SPLATLITE_3DGRUT", ""))
                               ).classes("w-full")
            ui.markdown("*Needed for training and for the PLY→USDZ conversion. "
                        "It must contain `train.py` and (ideally) its `.venv`.*").classes("text-xs")

        # -------------------------------------------------- input
        with ui.card().classes("w-full"):
            ui.label("1 · Input").classes("text-lg font-bold")
            colmap_dir = ui.input("COLMAP folder (contains images/ and sparse/0/)",
                                  value=settings.get("colmap", "")).classes("w-full")
            ply_in = ui.input("...or an already-trained .ply (skips training)").classes("w-full")
            out_dir = ui.input("Output folder",
                               value=settings.get("out", str(Path.home() / "splatlite_out"))).classes("w-full")
            iters = ui.number("Training iterations", value=30000, min=1000, step=1000)
            train_log = ui.log(max_lines=300).classes("w-full h-40 font-mono text-xs")
            status = ui.markdown("")

            def _load(p: Path):
                v, xyz, rgb = load_gaussians(p)
                state.update(v=v, xyz=xyz, rgb=rgb, keep=np.ones(len(xyz), bool))
                lo, hi = xyz.min(0), xyz.max(0)
                bounds_lbl.set_text(
                    f"{len(xyz)} gaussians | bounds min ({lo[0]:.1f}, {lo[1]:.1f}, {lo[2]:.1f}) "
                    f"max ({hi[0]:.1f}, {hi[1]:.1f}, {hi[2]:.1f}) [COLMAP scene units]")

            def do_train():
                if state["busy"]:
                    return ui.notify("Operation in progress", type="warning")
                repo = Path(g3_path.value).expanduser()
                if not (repo / "train.py").exists():
                    return ui.notify("Invalid 3dgrut folder (train.py missing)", type="negative")
                cm = Path(colmap_dir.value).expanduser()
                if not (cm / "sparse").exists():
                    return ui.notify("Invalid COLMAP folder (sparse/ missing)", type="negative")
                out = Path(out_dir.value).expanduser(); out.mkdir(parents=True, exist_ok=True)
                save_settings(gdrut=str(repo), colmap=str(cm), out=str(out))
                state["busy"] = True
                status.set_content("⏳ Training running... (logs above)")

                def worker():
                    try:
                        stream([gdrut_python(repo), "train.py",
                                "--config-name", "apps/colmap_3dgut.yaml",
                                f"path={cm}", f"out_dir={out}", "experiment_name=splatlite",
                                f"n_iterations={int(iters.value)}",
                                "export_ply.enabled=true"],
                               cwd=repo, env=gdrut_env(repo), on_line=train_log.push)
                        plys = sorted(out.rglob("export_last.ply"), key=lambda p: p.stat().st_mtime)
                        if plys:
                            _load(plys[-1])
                            status.set_content(f"✅ Training complete: `{plys[-1]}` — continue to step 2.")
                        else:
                            status.set_content("❌ Training finished but no export_last.ply found.")
                    except Exception as e:
                        status.set_content(f"❌ {e}")
                    finally:
                        state["busy"] = False
                threading.Thread(target=worker, daemon=True).start()

            def do_load():
                p = Path(ply_in.value).expanduser()
                if not p.exists():
                    return ui.notify(".ply not found", type="negative")
                _load(p)
                status.set_content(f"✅ Loaded `{p.name}` — continue to step 2.")

            with ui.row():
                ui.button("Train from COLMAP", icon="model_training", on_click=do_train).props("color=primary")
                ui.button("Load existing .ply", icon="folder_open", on_click=do_load)

        # -------------------------------------------- orientation
        with ui.card().classes("w-full"):
            ui.label("2 · Orientation").classes("text-lg font-bold")
            ui.markdown("*The COLMAP scene has an arbitrary orientation: level it here relative to the "
                        "horizontal plane before crop and export (the crop box is axis-aligned, "
                        "so level first). Rotations transform positions and per-gaussian "
                        "orientations; view-dependent reflections (spherical harmonics) are not "
                        "re-oriented — imperceptible for small angles.*").classes("text-xs")

            orient_lbl = ui.markdown("")

            def _bake(R):
                if state["xyz"] is None:
                    return ui.notify("Load a splat first", type="warning")
                state["xyz"] = apply_rotation(state["v"], state["xyz"], R)
                lo, hi = state["xyz"].min(0), state["xyz"].max(0)
                bounds_lbl.set_text(
                    f"{len(state['xyz'])} gaussians | bounds min ({lo[0]:.1f}, {lo[1]:.1f}, {lo[2]:.1f}) "
                    f"max ({hi[0]:.1f}, {hi[1]:.1f}, {hi[2]:.1f}) [unità scena]")
                draw_preview()

            def auto_ransac():
                if state["xyz"] is None:
                    return ui.notify("Load a splat first", type="warning")
                n, p, cnt = ransac_ground(state["xyz"])
                pct = 100 * cnt / min(len(state["xyz"]), 30000)
                _bake(align_normal_to_z(n))
                orient_lbl.set_content(
                    f"✅ **Auto-level (RANSAC)**: dominant plane with {pct:.0f}% inliers "
                    "made horizontal (normal → +Z). If it locked onto a wall instead of the "
                    "ground (very vertical scenes), refine manually or try PCA.")

            def auto_pca():
                if state["xyz"] is None:
                    return ui.notify("Load a splat first", type="warning")
                _bake(align_normal_to_z(pca_up(state["xyz"])))
                orient_lbl.set_content(
                    "✅ **PCA**: minimum-variance axis aligned to +Z. Reliable for "
                    "spread-out scenes; less so for tall or narrow ones.")

            def ground_zero():
                if state["xyz"] is None:
                    return ui.notify("Load a splat first", type="warning")
                z0 = np.percentile(state["xyz"][:, 2], 5)
                state["xyz"][:, 2] -= z0
                state["v"]["z"] = state["xyz"][:, 2].astype(np.float32)
                draw_preview()
                orient_lbl.set_content(f"✅ Translated: the 5th height percentile (≈ ground) is now at z=0 "
                                       f"(offset {z0:+.2f}).")

            with ui.row():
                ui.button("Auto-level (dominant plane)", icon="auto_fix_high",
                          on_click=auto_ransac).props("color=primary")
                ui.button("PCA principal axes", icon="align_vertical_bottom", on_click=auto_pca)
                ui.button("Ground to z=0", icon="vertical_align_bottom", on_click=ground_zero)

            ui.markdown("*Manual refinement: degrees around the centroid. Apply, check "
                        "the preview, repeat — each apply starts from the current orientation.*"
                        ).classes("text-xs")
            with ui.row():
                rx = ui.number("rot X (°)", value=0.0, step=0.5)
                ry = ui.number("rot Y (°)", value=0.0, step=0.5)
                rz = ui.number("rot Z (°)", value=0.0, step=0.5)

                def manual():
                    _bake(rot_matrix_xyz(float(rx.value), float(ry.value), float(rz.value)))
                    orient_lbl.set_content(f"✅ Manual rotation applied "
                                           f"({rx.value}°, {ry.value}°, {rz.value}°).")
                    rx.value = ry.value = rz.value = 0.0

                ui.button("Apply rotation", icon="360", on_click=manual)

        # ------------------------------------------------ cleanup
        with ui.card().classes("w-full"):
            ui.label("3 · Cleanup").classes("text-lg font-bold")
            bounds_lbl = ui.label("").classes("text-xs text-gray-500")

            with ui.row().classes("items-center"):
                min_op = ui.slider(min=0.0, max=0.5, step=0.01, value=0.05).classes("w-64")
                ui.label().bind_text_from(min_op, "value", lambda v: f"Min opacity: {v:.2f}")
            ui.markdown("*Removes near-transparent gaussians (residual training \"dust\"). "
                        "Higher = more cleaning; beyond ~0.2 you may thin out genuinely "
                        "semi-transparent surfaces (glass, dense foliage).*").classes("text-xs")

            with ui.row().classes("items-center"):
                max_sc = ui.slider(min=0.0, max=20.0, step=0.1, value=5.0).classes("w-64")
                ui.label().bind_text_from(max_sc, "value", lambda v: f"Max scale: {v:.1f}")
            ui.markdown("*Removes gaussians larger than this value (scene units: calibrate on the "
                        "bounds shown above). Giant blobs are typically sky or halos: start at "
                        "≈ 1/4 of the scene size and lower it until they vanish without punching "
                        "holes in real surfaces. 0 = filter off.*").classes("text-xs")

            with ui.row().classes("items-center"):
                out_k = ui.slider(min=0, max=40, step=1, value=12).classes("w-64")
                ui.label().bind_text_from(out_k, "value", lambda v: f"Neighbors analyzed (k): {int(v)}")
            with ui.row().classes("items-center"):
                out_std = ui.slider(min=0.5, max=4.0, step=0.1, value=2.0).classes("w-64")
                ui.label().bind_text_from(out_std, "value", lambda v: f"Outlier threshold (σ): {v:.1f}")
            ui.markdown("*Floater removal: for each gaussian, measures the mean distance to its k "
                        "nearest neighbors; anything more isolated than mean + σ standard deviations "
                        "is removed. σ 1–1.5 = aggressive, σ 3+ = conservative, k=0 = off.*"
                        ).classes("text-xs")

            crop_on = ui.switch("Crop box — keep only the region of interest")
            ui.markdown("*Everything outside the box is removed (e.g. distant background). "
                        "\"Fit to bounds\" sets the box to the whole scene (2–98 percentiles, robust "
                        "to floaters): then shrink it to the area you need.*").classes("text-xs")
            with ui.row():
                cx = ui.number("center X", value=0.0); cy = ui.number("center Y", value=0.0); cz = ui.number("center Z", value=0.0)
            with ui.row():
                sx = ui.number("size X", value=10.0); sy = ui.number("size Y", value=10.0); sz = ui.number("size Z", value=10.0)

            def fit_bounds():
                if state["xyz"] is None:
                    return ui.notify("Load a splat first", type="warning")
                lo = np.percentile(state["xyz"], 2, axis=0)
                hi = np.percentile(state["xyz"], 98, axis=0)
                c, s = (lo + hi) / 2, (hi - lo) * 1.05
                cx.value, cy.value, cz.value = [round(float(x), 2) for x in c]
                sx.value, sy.value, sz.value = [round(float(x), 2) for x in s]
                crop_on.value = True

            result_lbl = ui.markdown("")

            def apply_filters():
                if state["xyz"] is None:
                    return ui.notify("Load a splat first", type="warning")
                crop = ((cx.value, cy.value, cz.value), (sx.value, sy.value, sz.value)) if crop_on.value else None
                keep = compute_keep(state["v"], state["xyz"],
                                    min_opacity=float(min_op.value), max_scale=float(max_sc.value),
                                    out_k=int(out_k.value), out_std=float(out_std.value), crop=crop)
                state["keep"] = keep
                n0, n1 = len(keep), int(keep.sum())
                result_lbl.set_content(f"**{n0} → {n1} gaussians** (removed {n0 - n1}, "
                                       f"{100 * (n0 - n1) / max(n0, 1):.1f}%). Check the preview.")
                draw_preview()

            with ui.row():
                ui.button("Fit to bounds", icon="fit_screen", on_click=fit_bounds)
                ui.button("Apply filters", icon="cleaning_services", on_click=apply_filters).props("color=primary")

        # ------------------------------------------------ preview
        with ui.card().classes("w-full"):
            ui.label("4 · Preview").classes("text-lg font-bold")
            ui.markdown("*Points = gaussian centers (sampled, max 60k). Colored = kept, "
                        "light gray = removed by the filters. Red box = crop. Drag to orbit, "
                        "scroll to zoom.*").classes("text-xs")
            preview_holder = ui.column().classes("w-full")

            def draw_preview():
                if state["xyz"] is None:
                    return
                xyz, rgb, keep = state["xyz"], state["rgb"], state["keep"]
                idx = np.random.default_rng(0).choice(len(xyz), min(60000, len(xyz)), replace=False)
                preview_holder.clear()
                with preview_holder:
                    with ui.scene(width=900, height=500).classes("w-full") as sc:
                        ki, ri = idx[keep[idx]], idx[~keep[idx]]
                        if len(ki):
                            sc.point_cloud(points=xyz[ki].tolist(), colors=rgb[ki].tolist(),
                                           point_size=0.02)
                        if len(ri):
                            sc.point_cloud(points=xyz[ri].tolist(),
                                           colors=[[0.85, 0.85, 0.85]] * len(ri), point_size=0.012)
                        if crop_on.value:
                            box = sc.box(sx.value, sy.value, sz.value).material("#ff4444", opacity=0.15)
                            box.move(cx.value, cy.value, cz.value)

            ui.button("Refresh preview", icon="visibility", on_click=draw_preview)

        # ------------------------------------------------ export
        with ui.card().classes("w-full"):
            ui.label("5 · USDZ export").classes("text-lg font-bold")
            ui.markdown("*Saves the cleaned PLY and converts it to the Isaac Sim splat schema "
                        "(ParticleField3DGaussianSplat) using the official 3dgrut tooling. In Isaac: "
                        "**new stage and drag the .usdz in as a reference** — never open it as the "
                        "root stage (empty prim, known limitation).*").classes("text-xs")
            name = ui.input("Asset name", value="scene")
            export_lbl = ui.markdown("")

            def do_export():
                if state["xyz"] is None or state["keep"] is None:
                    return ui.notify("Apply the filters first", type="warning")
                out = Path(out_dir.value).expanduser(); out.mkdir(parents=True, exist_ok=True)
                ply_out = out / f"{name.value}_clean.ply"
                save_filtered(state["v"], state["keep"], ply_out)
                export_lbl.set_content("⏳ Clean PLY saved, converting to USDZ...")

                def worker():
                    repo = Path(g3_path.value).expanduser()
                    usdz = out / f"{name.value}.usdz"
                    conv = Path(__file__).resolve().parent / "splat_ply_to_usdz.py"
                    try:
                        # internal converter: drives the 3dgrut API with export_cameras=False
                        # (the official ply_to_usd script fails without a dataset)
                        stream([gdrut_python(repo), str(conv), str(ply_out),
                                "-o", str(usdz)],
                               cwd=repo, env=gdrut_env(repo), on_line=train_log.push)
                        export_lbl.set_content(f"✅ Done: **`{usdz}`** (clean PLY: `{ply_out}`)")
                    except Exception as e:
                        export_lbl.set_content(f"✅ Clean PLY: `{ply_out}` — ❌ USDZ conversion: {e}")
                threading.Thread(target=worker, daemon=True).start()

            ui.button("Export", icon="rocket", on_click=do_export).props("color=primary")

    ui.run(port=port, title="splatlite", reload=False, show=False)


def cli():
    import argparse
    ap = argparse.ArgumentParser(description="splatlite — COLMAP -> clean splat -> USDZ")
    ap.add_argument("--port", type=int, default=8081)
    args = ap.parse_args()
    main(port=args.port)


if __name__ in {"__main__", "__mp_main__"}:
    main()
