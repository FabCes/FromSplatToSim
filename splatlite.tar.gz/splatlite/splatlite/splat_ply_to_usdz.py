"""Convert a gaussian-splat PLY to USDZ (Isaac NuRec schema) from a bare PLY.

The official 3dgrut `ply_to_usd.py` hard-codes export_cameras=True, which fails
when there is no dataset (our case: a cleaned PLY). This script drives the same
3dgrut API but constructs the exporter with export_cameras=False.

Run WITH 3dgrut's own python (so its modules import):
    <3dgrut>/.venv/bin/python splat_ply_to_usdz.py in.ply -o out.usdz
"""
import argparse
import logging
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("splatlite.convert")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_file")
    ap.add_argument("-o", "--output_file")
    args = ap.parse_args()

    src = Path(args.input_file)
    if src.suffix.lower() != ".ply" or not src.exists():
        log.error("Invalid input (an existing .ply is required): %s", src)
        return 1
    dst = Path(args.output_file) if args.output_file else src.with_suffix(".usdz")
    dst.parent.mkdir(parents=True, exist_ok=True)

    from threedgrut.model.model import MixtureOfGaussians
    from threedgrut.export.usd.nurec.exporter import NuRecExporter
    try:
        from threedgrut.export.scripts.ply_to_usd import load_default_config
    except Exception:
        from threedgrut.utils.config import load_default_config  # fallback name

    conf = load_default_config()
    model = MixtureOfGaussians(conf)
    log.info("Loading PLY: %s", src)
    model.init_from_ply(str(src), init_model=False)

    log.info("Exporting USDZ (no cameras): %s", dst)
    exporter = NuRecExporter(export_cameras=False)
    exporter.export(model, dst, dataset=None, conf=conf)
    log.info("OK: %s", dst)
    return 0


if __name__ == "__main__":
    sys.exit(main())
