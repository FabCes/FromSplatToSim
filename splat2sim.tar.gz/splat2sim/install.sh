#!/usr/bin/env bash
# splat2sim installer (Linux + NVIDIA GPU)
# Idempotente: rilanciabile finche' tutto non e' verde. Usa `splat2sim doctor`
# per una diagnosi completa dello stack.
set -uo pipefail
cd "$(dirname "$0")"

bold() { printf "\033[1m%s\033[0m\n" "$*"; }
warn() { printf "\033[33m! %s\033[0m\n" "$*"; }
ok()   { printf "\033[32m+ %s\033[0m\n" "$*"; }
err()  { printf "\033[31mX %s\033[0m\n" "$*"; }

bold "== splat2sim install =="

# --------------------------------------------- pick a modern CUDA toolkit
# Prefer /usr/local/cuda-12.x / 11.8 over an old apt nvcc (e.g. 11.5).
BEST_CUDA=""
for d in /usr/local/cuda-13.* /usr/local/cuda-12.* /usr/local/cuda-11.8 /usr/local/cuda; do
  [ -x "$d/bin/nvcc" ] && BEST_CUDA="$d" && break
done
if [ -n "$BEST_CUDA" ]; then
  export PATH="$BEST_CUDA/bin:$PATH"
  export CUDA_HOME="$BEST_CUDA"
  ok "CUDA toolkit: $BEST_CUDA ($($BEST_CUDA/bin/nvcc --version | grep -oP 'release \K[0-9.]+'))"
elif command -v nvcc >/dev/null; then
  NV=$(nvcc --version | grep -oP 'release \K[0-9.]+')
  case "$NV" in
    11.8|12.*|13.*) ok "CUDA toolkit: nvcc $NV (PATH)";;
    *) UB=$( (lsb_release -rs 2>/dev/null || grep -oP 'VERSION_ID="\K[0-9.]+' /etc/os-release) | tr -d '.' | cut -c1-4 )
       case "$UB" in 2404*) REPO=ubuntu2404; TK=12-8;; 2204*) REPO=ubuntu2204; TK=12-4;; *) REPO=ubuntu2204; TK=12-4;; esac
       warn "nvcc $NV too old for the backends (11.8/12.x/13.x required)."
       warn "Install the official toolkit (coexists with the apt one):"
       warn "  wget https://developer.download.nvidia.com/compute/cuda/repos/${REPO}/x86_64/cuda-keyring_1.1-1_all.deb"
       warn "  sudo dpkg -i cuda-keyring_1.1-1_all.deb && sudo apt update && sudo apt install cuda-toolkit-${TK}"
       warn "  then re-run ./install.sh (it will find it in /usr/local/)";;
  esac
fi

# ---------------------------------------------------------- system checks
command -v nvidia-smi >/dev/null && ok "NVIDIA GPU detected" || warn "nvidia-smi not found: training requires an NVIDIA GPU + driver"
command -v ffmpeg >/dev/null && ok "ffmpeg" || warn "ffmpeg missing:  sudo apt install ffmpeg"
command -v colmap >/dev/null && ok "colmap" || warn "colmap missing:  sudo apt install colmap"

# ---------------------------------------------------------------- python
PY=${PYTHON:-python3}
[ -d .venv ] || $PY -m venv .venv
source .venv/bin/activate
pip install -q --upgrade pip
pip install -q -e ".[gui]" && ok "splat2sim installed in the .venv" || { err "pip install failed"; exit 1; }

# No torch needed in the main venv: each backend has its own environment.

# ------------------------------------------------- CUDA version detection
# Pick the torch wheel from the installed toolkit (nvcc) when present, since
# backend CUDA extensions are compiled with it; otherwise use the driver.
cuda_tag_for() {  # $1 = version like 12.4 / 12.8 / 13.0
  case "$1" in
    11.8*) echo cu118 ;;
    12.[0-3]*) echo cu121 ;;
    12.[45]*) echo cu124 ;;
    12.[67]*) echo cu126 ;;
    12.*) echo cu128 ;;
    13.*) echo cu128 ;;   # driver/toolkit 13.x: backward compatible with cu128 wheels
    *) echo "" ;;
  esac
}
CUDA_TAG=""
if [ -n "${BEST_CUDA:-}" ]; then
  NVCC_VER=$("$BEST_CUDA/bin/nvcc" --version | grep -oP 'release \K[0-9.]+')
  CUDA_TAG=$(cuda_tag_for "$NVCC_VER")
  ok "Toolkit nvcc $NVCC_VER -> torch wheel: ${CUDA_TAG:-default}"
elif command -v nvidia-smi >/dev/null; then
  CUDA_VER=$(nvidia-smi | grep -oP 'CUDA Version: \K[0-9]+\.[0-9]+' | head -1 || true)
  CUDA_TAG=$(cuda_tag_for "${CUDA_VER:-}")
  ok "CUDA driver ${CUDA_VER:-?} -> torch wheel: ${CUDA_TAG:-default}"
fi

mkdir -p third_party

# ----------------------------------------------------------------- 3dgrut
if [ ! -d third_party/3dgrut ]; then
  bold "-- 3dgrut (visual splat + Isaac Sim USDZ export)"
  git clone --recursive https://github.com/nv-tlabs/3dgrut.git third_party/3dgrut || err "3dgrut clone failed"
fi
NVCC_OK=0
if command -v nvcc >/dev/null; then
  case "$(nvcc --version | grep -oP 'release \K[0-9.]+')" in 11.8*|12.*|13.*) NVCC_OK=1;; esac
fi
if [ "$NVCC_OK" = 0 ]; then
  warn "Skipping backend setup: a CUDA toolkit 11.8/12.x is required first (see above)."
fi
if [ "$NVCC_OK" = 1 ] && [ -d third_party/3dgrut ] && [ ! -e third_party/3dgrut/.venv ]; then
  bold "-- 3dgrut environment setup (uses its official installer, needs the CUDA toolkit)"
  ( cd third_party/3dgrut && ./install_env_uv.sh ) \
    && ok "3dgrut ready" \
    || warn "3dgrut setup incomplete: cd into third_party/3dgrut and follow its README (requires nvcc/CUDA toolkit)."
else
  [ -d third_party/3dgrut ] && ok "3dgrut already configured"
fi

# ------------------------------------------------------------------- 2DGS
DGS=third_party/2d-gaussian-splatting
if [ ! -d "$DGS" ]; then
  bold "-- 2DGS (geometric mesh for the colliders)"
  git clone --recursive https://github.com/hbb1/2d-gaussian-splatting.git "$DGS" || err "2DGS clone failed"
fi
if [ "$NVCC_OK" = 1 ] && [ -d "$DGS" ] && [ ! -x "$DGS/.venv/bin/python" ]; then
  bold "-- 2DGS environment setup (dedicated venv + torch + CUDA submodules)"
  $PY -m venv "$DGS/.venv"
  DP="$DGS/.venv/bin/pip"
  "$DP" install -q --upgrade pip
  if [ -n "$CUDA_TAG" ]; then
    "$DP" install -q torch torchvision --index-url "https://download.pytorch.org/whl/${CUDA_TAG}" \
      || "$DP" install -q torch torchvision
  else
    "$DP" install -q torch torchvision
  fi
  "$DP" install -q numpy plyfile tqdm opencv-python-headless open3d scikit-image mediapy lpips trimesh
  "$DP" install -q setuptools wheel ninja
  # CUDA extensions: --no-build-isolation so the build sees the venv torch
  if "$DP" install -q --no-build-isolation "$DGS/submodules/diff-surfel-rasterization" "$DGS/submodules/simple-knn"; then
    ok "2DGS ready (CUDA extensions compiled)"
  else
    warn "2DGS extension build failed: usually the CUDA toolkit (nvcc) is missing"
    warn "  sudo apt install nvidia-cuda-toolkit   # or the official NVIDIA toolkit"
    warn "  then re-run ./install.sh (resumes from here)"
    rm -rf "$DGS/.venv"
  fi
else
  [ -d "$DGS" ] && ok "2DGS already configured"
fi

bold "== summary =="
echo "Full diagnosis:      splat2sim doctor"
echo "Activate env:        source .venv/bin/activate"
echo "GUI:                 splat2sim gui   -> http://localhost:8080"
echo "CLI:                 splat2sim init progetti/scena1 --video capture.mp4"
