# splat2sim

**Video (+ optional lidar) → 3D Gaussian Splat → simulation-ready USD/USDZ asset for NVIDIA Isaac Sim.**

Full guided pipeline in six resumable steps, with a CLI and a web GUI. Produces a two-layer asset: photorealistic gaussian splat for rendering, plus invisible aligned physics colliders (structure + optional hole-free ground).

## Install (Ubuntu 22.04 / 24.04, NVIDIA GPU)
```bash
tar xzf splat2sim.tar.gz && cd splat2sim
./install.sh              # venv + backends (3dgrut, 2DGS) with their own envs
source .venv/bin/activate
splat2sim doctor          # verifies ffmpeg, colmap, CUDA toolkit, backends
```
`install.sh` is idempotent: fix what `doctor` reports and re-run it.

## Use
```bash
splat2sim init myscene --video capture.mp4 [--lidar scan.ply] [--preset outdoor|object]
splat2sim run  myscene                 # all steps: ingest → poses → train_splat →
                                       # train_geo → cleanup → export
splat2sim run  myscene --step cleanup  # single step (steps are resumable)
splat2sim status myscene
splat2sim gui                          # web wizard at http://localhost:8080
```

### Orientation (level the scene before crop/export)
```bash
splat2sim orient myscene --auto           # RANSAC dominant plane → horizontal
splat2sim orient myscene --pca            # minimum-variance axis → +Z
splat2sim orient myscene --rotate 0,0,15  # manual degrees
splat2sim orient myscene --ground-zero    # 5th height percentile → z=0
```
Rotations are applied consistently to the splat (positions + per-gaussian quaternions) and the geometric mesh.

## Key configuration (project.yaml)
- `geo.engine`: `2dgs` (TSDF mesh from a second training pass, best quality),
  `gaussians` (mesh straight from the trained splat: voxel density + marching
  cubes, no GPU, seconds instead of minutes), or `none`.
- `cleanup`: `min_opacity`, `max_scale`, statistical outlier removal, crop box,
  `target_faces`; component filters `min_extent`, `max_hover`,
  `hover_max_extent` (see the project README for what each does).
- `ground`: `enabled`, `smooth`, `grid_res`, `percentile`, `object_size`,
  `robust_band` — dedicated hole-free terrain collider.
- `export`: `mode` static/dynamic, `scale_to_meters`, `semantic_label`.

## In Isaac Sim (≥ 5.0)
Create a **new stage** and drag the `.usdz` in as a **reference** (never open it as the root stage). Verify colliders with Show → Physics → Colliders. The COLMAP scene is not metric: measure a known distance and set `export.scale_to_meters = real / measured`.
