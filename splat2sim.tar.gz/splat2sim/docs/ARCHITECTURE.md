# Architettura

Vedi README per la panoramica. Punti chiave di design:

- **Un progetto = una cartella**: `project.yaml` + sottocartelle numerate per step.
  Stato in `.state.json` → pipeline resumabile, ogni step rieseguibile con `--force`.
- **Coerenza visivo/fisico**: il `CropBox` di `config.py` è l'unica fonte di verità
  per la regione di interesse ed è applicato sia alle gaussiane sia alla mesh.
- **Backend esterni disaccoppiati**: `steps/train.py` invoca i repo in `third_party/`
  con i loro venv (override con SPLAT2SIM_3DGRUT / SPLAT2SIM_2DGS / SPLAT2SIM_PGSR).
  Cambiare backend = cambiare `splat.engine` / `geo.engine` nel YAML.
- **Exporter isolato** (`steps/export_usd.py`): lo schema USDZ degli splat di
  3dgrut/Isaac è dichiarato beta; se cambia si aggiorna solo questo modulo.
- **GUI sottile**: `gui.py` chiama le stesse funzioni della CLI (`cli._dispatch`),
  nessuna logica duplicata.

## Roadmap
- Editor di crop interattivo con rendering splat nel browser (viser / gsplat.js)
  e selezione lazo dei floater.
- Supporto rosbag LiDAR-inerziale (stile GS-SDF / FAST-LIVO2) per scala e
  geometria outdoor migliore.
- Calibrazione scala guidata: click su due punti a distanza nota nella preview.
