"""splat2sim command line.

    splat2sim init myscene --video capture.mp4 [--preset outdoor|object] [--lidar cloud.ply]
    splat2sim run  myscene                 # full pipeline (resumes from last done step)
    splat2sim run  myscene --step cleanup  # single step
    splat2sim status myscene
    splat2sim gui                          # launch the web wizard
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer

from .project import Project, STEPS
from .utils.run import ToolMissing, log

app = typer.Typer(add_completion=False, help="Video (+lidar) -> Gaussian Splat -> USD/USDZ for Isaac Sim")


@app.command()
def init(folder: Path,
         video: Optional[Path] = typer.Option(None, help="Input video (.mp4)"),
         lidar: Optional[Path] = typer.Option(None, help="Optional lidar point cloud (.ply/.las/.pcd)"),
         preset: str = typer.Option("outdoor", help="outdoor | object"),
         name: Optional[str] = typer.Option(None, help="Asset name (default: folder name)")):
    """Create a new project."""
    p = Project.create(folder, name or folder.name, preset)
    if video:
        p.cfg.ingest.video = str(Path(video).resolve())
    if lidar:
        p.cfg.ingest.lidar = str(Path(lidar).resolve())
    p.save()
    typer.echo(f"Project created in {folder} (preset: {preset}).")
    typer.echo(f"Edit {folder}/project.yaml if needed, then: splat2sim run {folder}")


@app.command()
def run(folder: Path,
        step: Optional[str] = typer.Option(None, help=f"Run a single step: {'|'.join(STEPS)}"),
        force: bool = typer.Option(False, help="Re-run steps already completed")):
    """Run the pipeline (or a single step)."""
    p = Project(folder)
    steps = [step] if step else STEPS
    try:
        for s in steps:
            if not force and step is None and p.is_done(s):
                log.info("-- %s: already done, skipping (use --force to redo)", s)
                continue
            log.info("== STEP %s ==", s.upper())
            _dispatch(p, s)
    except ToolMissing as e:
        typer.secho(f"\nMissing tool: {e}", fg="red")
        raise typer.Exit(1)
    typer.secho("\nPipeline complete.", fg="green")


def _dispatch(p: Project, s: str) -> None:
    if s == "ingest":
        from .steps.ingest import extract_frames, normalize_lidar
        extract_frames(p)
        normalize_lidar(p)
    elif s == "poses":
        from .steps.poses import run_sfm
        run_sfm(p)
    elif s == "train_splat":
        from .steps.train import train_splat
        train_splat(p)
    elif s == "train_geo":
        from .steps.train import train_geo
        train_geo(p)
    elif s == "cleanup":
        from .steps.cleanup import run_cleanup
        run_cleanup(p)
    elif s == "export":
        from .steps.export_usd import export_asset
        export_asset(p)
    else:
        raise typer.BadParameter(f"Unknown step: {s}")


@app.command()
def orient(folder: Path,
           auto: bool = typer.Option(False, help="Auto-level: dominant plane (RANSAC) -> horizontal"),
           pca: bool = typer.Option(False, help="Auto-level: minimum-variance axis -> +Z"),
           rotate: Optional[str] = typer.Option(None, help="Manual rotation deg 'rx,ry,rz'"),
           ground_zero: bool = typer.Option(False, help="Translate so the 5th height percentile sits at z=0")):
    """Level / rotate the scene BEFORE crop and export. Applies consistently to
    both the trained splat (positions + per-gaussian quaternions) and the
    geometric mesh, so the two layers stay aligned."""
    import numpy as np
    import trimesh
    from .splatops import (align_normal_to_z, load_gaussian_ply, pca_up,
                           ransac_ground_normal, rot_matrix_xyz, rotate_gaussians,
                           save_gaussian_ply)
    p = Project(folder)
    state = p._state()
    ply = state.get("train_splat", {}).get("ply")
    if not ply:
        typer.secho("Run 'train_splat' first.", fg="red"); raise typer.Exit(1)
    v, xyz, _ = load_gaussian_ply(Path(ply))

    R = None
    if auto:
        n, _, cnt = ransac_ground_normal(xyz)
        R = align_normal_to_z(n)
        typer.echo(f"RANSAC dominant plane: {cnt} inliers -> leveled")
    elif pca:
        R = align_normal_to_z(pca_up(xyz))
        typer.echo("PCA minimum-variance axis aligned to +Z")
    elif rotate:
        rx, ry, rz = (float(x) for x in rotate.split(","))
        R = rot_matrix_xyz(rx, ry, rz)

    pivot = xyz.mean(0)
    if R is not None:
        xyz = rotate_gaussians(v, R, pivot)
    if ground_zero:
        z0 = float(np.percentile(xyz[:, 2], 5))
        v["z"] = (xyz[:, 2] - z0).astype("f4")
        typer.echo(f"Translated: ground at z=0 (offset {z0:+.2f})")
    if R is None and not ground_zero:
        typer.echo("Nothing to do: pass --auto, --pca, --rotate or --ground-zero")
        raise typer.Exit(0)
    save_gaussian_ply(v, Path(ply))

    mesh_p = state.get("train_geo", {}).get("mesh")
    if mesh_p and Path(mesh_p).exists():
        m = trimesh.load(mesh_p, force="mesh")
        if R is not None:
            m.vertices = (m.vertices - pivot) @ R.T + pivot
        if ground_zero:
            m.vertices[:, 2] -= z0
        m.export(mesh_p)
        typer.echo("Mesh rotated consistently with the splat")
    typer.secho("Orientation applied. Re-run 'cleanup' to refresh crop/filters.", fg="green")


@app.command()
def status(folder: Path):
    """Show project step status."""
    p = Project(folder)
    for s, meta in p.status().items():
        mark = "✓" if meta.get("done") else "·"
        extra = meta.get("at", "")
        typer.echo(f" {mark} {s:<12} {extra}")


@app.command()
def doctor():
    """Check the stack: system tools, GPU, third_party backends."""
    import shutil
    import subprocess
    from pathlib import Path as P

    root = P(__file__).resolve().parents[1]
    ok_all = True

    def check(name: str, good: bool, fix: str = ""):
        nonlocal ok_all
        mark = typer.style("✓", fg="green") if good else typer.style("✗", fg="red")
        typer.echo(f" {mark} {name}" + ("" if good else f"   → {fix}"))
        ok_all &= good

    check("ffmpeg", shutil.which("ffmpeg") is not None, "sudo apt install ffmpeg")
    check("colmap", shutil.which("colmap") is not None, "sudo apt install colmap")
    check("glomap (optional)", shutil.which("glomap") is not None,
          "optional: https://github.com/colmap/glomap")

    gpu = shutil.which("nvidia-smi") is not None
    check("NVIDIA driver (nvidia-smi)", gpu, "install the NVIDIA driver")
    if gpu:
        try:
            out = subprocess.check_output(["nvidia-smi", "--query-gpu=name,memory.total",
                                           "--format=csv,noheader"], text=True).strip()
            typer.echo(f"     {out}")
        except Exception:
            pass
    nvcc_ver, nvcc_ok = None, False
    import glob as _glob
    _cands = sorted(_glob.glob("/usr/local/cuda-13*/bin/nvcc"), reverse=True) + \
        sorted(_glob.glob("/usr/local/cuda-12*/bin/nvcc"), reverse=True) + \
        ["/usr/local/cuda-11.8/bin/nvcc", "/usr/local/cuda/bin/nvcc", shutil.which("nvcc")]
    for cand in _cands:
        if cand and P(cand).exists():
            try:
                out = subprocess.check_output([cand, "--version"], text=True)
                import re
                m = re.search(r"release ([0-9.]+)", out)
                nvcc_ver = m.group(1) if m else "?"
                nvcc_ok = nvcc_ver.startswith(("11.8", "12.", "13."))
                if nvcc_ok:
                    pass
                break
            except Exception:
                pass
    check(f"CUDA toolkit nvcc {nvcc_ver or 'missing'} (needs 11.8/12.x/13.x)", nvcc_ok,
          "Ubuntu 22.04: cuda-toolkit-12-4; Ubuntu 24.04: cuda-toolkit-12-8 (NVIDIA repo, see install.sh)")

    tp = root / "third_party"
    g3 = tp / "3dgrut"
    check("3dgrut cloned", g3.exists(), "./install.sh")
    check("3dgrut environment (.venv)", (g3 / ".venv/bin/python").exists(),
          "cd third_party/3dgrut && ./install_env_uv.sh")
    d2 = tp / "2d-gaussian-splatting"
    check("2DGS cloned", d2.exists(), "./install.sh")
    py2 = d2 / ".venv/bin/python"
    check("2DGS environment (.venv)", py2.exists(), "./install.sh (resumes from here)")
    if py2.exists():
        try:
            out = subprocess.check_output(
                [str(py2), "-c",
                 "import torch, diff_surfel_rasterization, simple_knn;"
                 "print(torch.__version__, torch.cuda.is_available())"],
                text=True, stderr=subprocess.STDOUT).strip()
            check(f"2DGS torch+estensioni CUDA ({out})", "True" in out,
                  "torch cannot see the GPU: incompatible driver/toolkit")
        except subprocess.CalledProcessError as e:
            check("2DGS torch+CUDA extensions", False,
                  f"import failed: {(e.output or '').strip().splitlines()[-1] if e.output else e}")

    typer.echo()
    if ok_all:
        typer.secho("All set. You can run the pipeline.", fg="green")
    else:
        typer.secho("Some requirements are missing: fix the ✗ lines and re-run 'splat2sim doctor'.",
                    fg="yellow")


@app.command()
def gui(port: int = 8080):
    """Start the web GUI (guided wizard)."""
    from .gui import main
    main(port=port)


@app.command()
def lite(port: int = 8081):
    """Light GUI: existing COLMAP -> splat -> parametric cleanup -> USDZ (no mesh/physics)."""
    from .lite import main
    main(port=port)


if __name__ == "__main__":
    app()
