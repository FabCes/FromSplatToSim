"""Subprocess runner with live logging + external tool discovery."""
from __future__ import annotations

import logging
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Callable, Optional, Sequence

log = logging.getLogger("splat2sim")
if not log.handlers:
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(logging.Formatter("[%(asctime)s] %(message)s", "%H:%M:%S"))
    log.addHandler(h)
    log.setLevel(logging.INFO)


class ToolMissing(RuntimeError):
    """An external tool is not installed. The message tells the user how to fix it."""


HINTS = {
    "ffmpeg": "sudo apt install ffmpeg",
    "colmap": "sudo apt install colmap   (build with CUDA for GPU acceleration:"
              " https://colmap.github.io/install.html)",
    "glomap": "https://github.com/colmap/glomap  (optional, faster global SfM)",
}


def require(tool: str) -> str:
    path = shutil.which(tool)
    if not path:
        hint = HINTS.get(tool, "")
        raise ToolMissing(f"'{tool}' not found on PATH. Install: {hint}")
    return path


def has_cuda_gpu() -> bool:
    return shutil.which("nvidia-smi") is not None


def run(cmd: Sequence[str], cwd: Optional[Path] = None,
        log_file: Optional[Path] = None,
        on_line: Optional[Callable[[str], None]] = None,
        env: Optional[dict] = None) -> None:
    """Run a command streaming stdout/stderr to the logger, a file, and an
    optional callback (used by the GUI to show live logs)."""
    log.info("$ %s", " ".join(str(c) for c in cmd))
    lf = open(log_file, "a") if log_file else None
    try:
        import os
        full_env = {**os.environ, **(env or {})} if env else None
        proc = subprocess.Popen(
            [str(c) for c in cmd], cwd=str(cwd) if cwd else None, env=full_env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        assert proc.stdout is not None
        for line in proc.stdout:
            line = line.rstrip()
            log.info(line)
            if lf:
                lf.write(line + "\n")
            if on_line:
                on_line(line)
        rc = proc.wait()
        if rc != 0:
            raise RuntimeError(f"Command failed (exit {rc}): {' '.join(map(str, cmd))}")
    finally:
        if lf:
            lf.close()
