"""splatops — shared geometry operations for the splat2sim pipeline.

Everything here is pure NumPy/SciPy/trimesh (no GPU):

* Orientation: manual rotation, RANSAC dominant-plane auto-leveling, PCA
  principal-axes leveling. Rotations are applied to gaussian positions AND
  per-gaussian quaternions so the splat stays consistent.
* Ground: hole-free heightfield of the terrain over the full XY extent,
  with a robust artifact-rejection filter (handles misaligned cloud patches,
  both pits and bumps), a morphological object filter (localized bumps such
  as small clutter are not terrain), and aggressive smoothing.
* Meshing: collider mesh directly from the gaussians (voxel density +
  marching cubes) — no second training pass required.
* Component filters: remove disconnected artifacts by physical extent and
  by ground clearance, while explicitly preserving extended elevated
  geometry (e.g. canopies, cables, rows of vegetation).
"""
from __future__ import annotations

import numpy as np
import trimesh
from pathlib import Path
from plyfile import PlyData, PlyElement

from .utils.run import log

SH_C0 = 0.28209479177387814


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


# ------------------------------------------------------------------- I/O
def load_gaussian_ply(path: Path):
    """Return (structured vertex array, xyz, rgb) from a 3DGS .ply.
    The array is materialized (copied out of plyfile's mmap) so it is safe to
    modify it and write back to the SAME file."""
    v = np.array(PlyData.read(str(path))["vertex"].data)
    xyz = np.vstack([v["x"], v["y"], v["z"]]).T.astype(np.float64)
    if all(f"f_dc_{i}" in v.dtype.names for i in range(3)):
        dc = np.vstack([v[f"f_dc_{i}"] for i in range(3)]).T
        rgb = np.clip(0.5 + SH_C0 * dc, 0, 1)
    else:
        rgb = np.full((len(xyz), 3), 0.6)
    return v, xyz, rgb


def save_gaussian_ply(v, dst: Path) -> None:
    PlyData([PlyElement.describe(v, "vertex")]).write(str(dst))


# ----------------------------------------------------------- orientation
def rot_matrix_xyz(rx, ry, rz):
    """Rotation matrix from degrees (applied X, then Y, then Z)."""
    a, b, c = np.radians([rx, ry, rz])
    Rx = np.array([[1, 0, 0], [0, np.cos(a), -np.sin(a)], [0, np.sin(a), np.cos(a)]])
    Ry = np.array([[np.cos(b), 0, np.sin(b)], [0, 1, 0], [-np.sin(b), 0, np.cos(b)]])
    Rz = np.array([[np.cos(c), -np.sin(c), 0], [np.sin(c), np.cos(c), 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def mat_to_quat(R):
    w = np.sqrt(max(0.0, 1 + R[0, 0] + R[1, 1] + R[2, 2])) / 2
    if w > 1e-8:
        x = (R[2, 1] - R[1, 2]) / (4 * w)
        y = (R[0, 2] - R[2, 0]) / (4 * w)
        z = (R[1, 0] - R[0, 1]) / (4 * w)
    else:
        x, y, z, w = 0.0, 0.0, 0.0, 1.0
    return np.array([w, x, y, z])


def quat_mul(q1, q2):
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2[..., 0], q2[..., 1], q2[..., 2], q2[..., 3]
    return np.stack([
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2], axis=-1)


def rotate_gaussians(v, R, pivot):
    """Rotate positions and per-gaussian quaternions in place. Note: spherical
    harmonics of degree > 0 are not re-oriented (negligible for leveling)."""
    xyz = np.vstack([v["x"], v["y"], v["z"]]).T.astype(np.float64)
    new = (xyz - pivot) @ R.T + pivot
    v["x"], v["y"], v["z"] = (new[:, 0].astype(np.float32),
                              new[:, 1].astype(np.float32),
                              new[:, 2].astype(np.float32))
    if all(f"rot_{i}" in v.dtype.names for i in range(4)):
        q = np.vstack([v[f"rot_{i}"] for i in range(4)]).T.astype(np.float64)
        qn = quat_mul(mat_to_quat(R), q)
        qn /= np.linalg.norm(qn, axis=1, keepdims=True) + 1e-12
        for i in range(4):
            v[f"rot_{i}"] = qn[:, i].astype(np.float32)
    return new


def align_normal_to_z(normal):
    n = normal / (np.linalg.norm(normal) + 1e-12)
    z = np.array([0.0, 0.0, 1.0])
    vx = np.cross(n, z); c = float(np.dot(n, z)); s = np.linalg.norm(vx)
    if s < 1e-9:
        return np.eye(3) if c > 0 else np.diag([1.0, -1.0, -1.0])
    vx = vx / s
    K = np.array([[0, -vx[2], vx[1]], [vx[2], 0, -vx[0]], [-vx[1], vx[0], 0]])
    ang = np.arctan2(s, c)
    return np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * (K @ K)


def ransac_ground_normal(xyz, iters=300, rel_thresh=0.01, seed=0):
    """Dominant plane via RANSAC -> (up-oriented normal, point, inlier count)."""
    rng = np.random.default_rng(seed)
    diag = np.linalg.norm(xyz.max(0) - xyz.min(0))
    th = rel_thresh * diag
    sub = xyz[rng.choice(len(xyz), min(len(xyz), 30000), replace=False)]
    best_n, best_p, best_cnt = None, None, -1
    for _ in range(iters):
        p3 = sub[rng.choice(len(sub), 3, replace=False)]
        n = np.cross(p3[1] - p3[0], p3[2] - p3[0])
        ln = np.linalg.norm(n)
        if ln < 1e-9:
            continue
        n = n / ln
        cnt = int((np.abs((sub - p3[0]) @ n) < th).sum())
        if cnt > best_cnt:
            best_n, best_p, best_cnt = n, p3[0], cnt
    if np.median((sub - best_p) @ best_n) < 0:
        best_n = -best_n
    return best_n, best_p, best_cnt


def pca_up(xyz):
    """Minimum-variance axis (a good 'up' candidate for spread-out scenes)."""
    sub = xyz - xyz.mean(0)
    sel = sub[np.random.default_rng(0).choice(len(sub), min(len(sub), 50000), replace=False)]
    w, V = np.linalg.eigh(np.cov(sel.T))
    n = V[:, 0]
    if np.median(sub @ n) < 0:
        n = -n
    return n


# ---------------------------------------------------------------- ground
def build_ground(xyz, *, grid_res: int = 120, percentile: float = 5.0,
                 smooth: float = 4.0, margin: float = 0.0,
                 object_size: float = 0.0, bump_thresh: float = 0.0,
                 robust_band: float = 0.0) -> trimesh.Trimesh:
    """Hole-free terrain heightfield over the full XY extent of the scene.

    - per XY cell, take a low percentile of the heights (the ground, ignoring
      anything built/grown above it);
    - fill empty cells by nearest-neighbor interpolation (no holes by
      construction);
    - robust artifact filter (robust_band > 0): iteratively estimate a smooth
      reference terrain from coherent cells only (masked normalized
      convolution with region growing) and replace cells deviating more than
      the band — both pits and bumps caused by misaligned cloud patches;
    - morphological object filter (object_size > 0): localized bumps with a
      footprint up to object_size (small clutter, low vegetation) are not
      terrain and get flattened; extended relief (hills, slopes) survives;
    - aggressive gaussian smoothing keeps only the general trend.
    """
    from scipy.ndimage import gaussian_filter, distance_transform_edt

    lo, hi = xyz.min(0), xyz.max(0)
    lo2, hi2 = lo[:2] - margin, hi[:2] + margin
    span = hi2 - lo2
    cell = float(span.max() / grid_res)
    nx, ny = (np.ceil(span / cell).astype(int) + 1)
    log.info("Ground: %dx%d grid (cell %.3f)", nx, ny, cell)

    ix = np.clip(((xyz[:, 0] - lo2[0]) / cell).astype(int), 0, nx - 1)
    iy = np.clip(((xyz[:, 1] - lo2[1]) / cell).astype(int), 0, ny - 1)
    flat = ix * ny + iy
    order = np.argsort(flat, kind="stable")
    flat_s, z_s = flat[order], xyz[order, 2]
    H = np.full(nx * ny, np.nan)
    starts = np.searchsorted(flat_s, np.arange(nx * ny))
    ends = np.searchsorted(flat_s, np.arange(nx * ny) + 1)
    for i in np.flatnonzero(ends > starts):
        H[i] = np.percentile(z_s[starts[i]:ends[i]], percentile)
    H = H.reshape(nx, ny)

    if np.isnan(H).any():
        mask = np.isnan(H)
        idx = distance_transform_edt(mask, return_distances=False, return_indices=True)
        H = H[tuple(idx)]
        log.info("Ground: filled %d empty cells (%.0f%%)", mask.sum(),
                 100 * mask.sum() / H.size)

    if robust_band and robust_band > 0:
        from scipy.ndimage import binary_dilation
        ref_sigma = max(6.0, 2.0 * float(smooth))
        good = np.ones_like(H, dtype=bool)
        prev_bad = 0
        for _ in range(10):
            w = good.astype(np.float32)
            ref = gaussian_filter(H * w, sigma=ref_sigma) / \
                (gaussian_filter(w, sigma=ref_sigma) + 1e-9)
            bad = np.abs(H - ref) > float(robust_band)
            bad = binary_dilation(bad, iterations=1) & \
                (np.abs(H - ref) > 0.5 * float(robust_band))
            good = ~bad
            if int(bad.sum()) == prev_bad:
                break
            prev_bad = int(bad.sum())
        n_bad = int((~good).sum())
        if n_bad:
            idx = distance_transform_edt(~good, return_distances=False,
                                         return_indices=True)
            H = np.where(good, H, H[tuple(idx)])
        log.info("Ground: artifact filter (band %.3f): corrected %d cells (%.0f%%)",
                 robust_band, n_bad, 100 * n_bad / H.size)

    if object_size and object_size > 0:
        from scipy.ndimage import grey_opening
        win = max(3, int(np.ceil(object_size / cell)) | 1)
        opened = grey_opening(H, size=(win, win))
        th = bump_thresh if bump_thresh > 0 else 0.02 * max(H.max() - H.min(), 1e-9)
        obj = (H - opened) > th
        H = np.where(obj, opened, H)
        log.info("Ground: object filter (window %d cells = %.2f units, thr %.3f): "
                 "flattened %d cells (%.0f%%)", win, win * cell, th,
                 int(obj.sum()), 100 * obj.sum() / H.size)

    H = gaussian_filter(H, sigma=float(smooth))

    xs = lo2[0] + np.arange(nx) * cell
    ys = lo2[1] + np.arange(ny) * cell
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    verts = np.c_[X.ravel(), Y.ravel(), H.ravel()]
    ii, jj = np.meshgrid(np.arange(nx - 1), np.arange(ny - 1), indexing="ij")
    a = (ii * ny + jj).ravel(); b = a + ny; c = a + 1; d = b + 1
    faces = np.r_[np.c_[a, b, c], np.c_[c, b, d]]
    ground = trimesh.Trimesh(vertices=verts, faces=faces, process=False)
    log.info("Ground mesh: %d triangles, heights %.2f..%.2f",
             len(ground.faces), H.min(), H.max())
    return ground


# --------------------------------------------------- gaussians -> mesh
def mesh_from_gaussians(ply_path: Path, *, grid_res: int = 300,
                        iso: float = 0.35, pad: int = 3,
                        max_grid: int = 448) -> trimesh.Trimesh:
    """Collider mesh straight from the gaussians (no second training pass):
    deposit opacity-weighted density on a voxel grid, smooth by the median
    gaussian scale, run marching cubes at the iso threshold.

    iso: lower = thicker, more closed surface (robust colliders);
         higher = tighter fit but possible holes.
    """
    from scipy.ndimage import gaussian_filter
    from skimage.measure import marching_cubes

    v = PlyData.read(str(ply_path))["vertex"].data
    xyz = np.vstack([v["x"], v["y"], v["z"]]).T.astype(np.float64)
    names = v.dtype.names
    op = sigmoid(np.asarray(v["opacity"], float)) if "opacity" in names else np.ones(len(xyz))
    if all(f"scale_{i}" in names for i in range(3)):
        smax = np.exp(np.vstack([v[f"scale_{i}"] for i in range(3)]).T.astype(float)).max(axis=1)
    else:
        smax = np.full(len(xyz), 0.01)

    lo, hi = xyz.min(0), xyz.max(0)
    diag = float(np.linalg.norm(hi - lo))
    voxel = diag / float(grid_res)
    dims = np.ceil((hi - lo) / voxel).astype(int) + 2 * pad + 1
    if dims.max() > max_grid:
        voxel = float((hi - lo).max() / (max_grid - 2 * pad - 1))
        dims = np.ceil((hi - lo) / voxel).astype(int) + 2 * pad + 1
    log.info("Voxel grid %s (voxel %.4f)", dims.tolist(), voxel)

    grid = np.zeros(dims, dtype=np.float32)
    idx = np.floor((xyz - lo) / voxel).astype(int) + pad
    np.add.at(grid, (idx[:, 0], idx[:, 1], idx[:, 2]), op.astype(np.float32))
    sigma_units = float(np.clip(np.median(smax), voxel, 4 * voxel))
    grid = gaussian_filter(grid, sigma=sigma_units / voxel)
    g99 = np.percentile(grid[grid > 0], 99) if (grid > 0).any() else 1.0
    grid = np.clip(grid / max(g99, 1e-9), 0, 1)

    verts, faces, _, _ = marching_cubes(grid, level=float(iso))
    verts = (verts - pad) * voxel + lo
    mesh = trimesh.Trimesh(vertices=verts, faces=faces, process=True)
    log.info("Marching cubes: %d faces", len(mesh.faces))
    return mesh


# ------------------------------------------------------ component filters
def filter_components(mesh: trimesh.Trimesh, *, min_extent: float = 0.0,
                      ground: trimesh.Trimesh | None = None,
                      max_hover: float = 0.0,
                      hover_max_extent: float = 0.0) -> trimesh.Trimesh:
    """Per-connected-component artifact filters for the structure collider.

    min_extent: minimum physical size (bbox diagonal, scene units): localized
        blobs are removed regardless of face count. 0 = off.
    ground + max_hover: FLOATING filter: components whose lowest point sits
        more than max_hover above the terrain at that XY are suspended
        artifacts. 0 = off.
    hover_max_extent: the floating filter only applies to components SMALLER
        than this bbox diagonal — extended elevated geometry (canopies,
        cables, elevated decks) is never removed even if it does not touch
        the ground: an artifact is suspended AND localized. 0 = applies to all.
    """
    comps = mesh.split(only_watertight=False)
    if len(comps) <= 1 and min_extent <= 0:
        return mesh
    gv = ground.vertices if ground is not None else None
    kept, drop_ext, drop_fly = [], 0, 0
    for c in comps:
        if min_extent > 0:
            if float(np.linalg.norm(c.bounds[1] - c.bounds[0])) < min_extent:
                drop_ext += 1
                continue
        if gv is not None and max_hover > 0:
            if hover_max_extent > 0 and \
                    float(np.linalg.norm(c.bounds[1] - c.bounds[0])) >= hover_max_extent:
                kept.append(c)
                continue
            i = int(np.argmin(c.vertices[:, 2]))
            px, py, pz = c.vertices[i]
            j = np.argmin((gv[:, 0] - px) ** 2 + (gv[:, 1] - py) ** 2)
            if pz - gv[j, 2] > max_hover:
                drop_fly += 1
                continue
        kept.append(c)
    log.info("Components: kept %d, removed %d below extent %.2f, "
             "removed %d floating (> %.2f above ground)",
             len(kept), drop_ext, min_extent, drop_fly, max_hover)
    if not kept:
        log.info("WARNING: filters too strict, keeping the largest component")
        kept = [max(comps, key=lambda m: len(m.faces))]
    return trimesh.util.concatenate(kept) if len(kept) > 1 else kept[0]
