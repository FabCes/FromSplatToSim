"""splat2sim GUI — web wizard (NiceGUI).

Runs locally or on a remote GPU box (open http://host:8080 in a browser).
Guides you through: project setup -> pipeline (live logs) -> orientation ->
crop & cleanup with 3D preview -> ground layer -> export USD/USDZ.
"""
from __future__ import annotations

import threading
import traceback
from pathlib import Path

import numpy as np
from nicegui import app, ui

from .project import Project, STEPS
from .utils import run as runner

STEP_LABELS = {
    "ingest": "1 · Frames from video",
    "poses": "2 · Camera poses (COLMAP)",
    "train_splat": "3 · Splat training (visual)",
    "train_geo": "4 · Geometry training (mesh)",
    "cleanup": "5 · Cleanup & crop",
    "export": "6 · USD export",
}

state: dict = {"project": None, "busy": False}


def main(port: int = 8080) -> None:
    @ui.page("/")
    def index():
        ui.markdown("## splat2sim — video → gaussian splat → USD asset for Isaac Sim")
        with ui.stepper().props("vertical").classes("w-full") as stepper:

            # ---------------------------------------------------- setup
            with ui.step("Project"):
                folder = ui.input("Project folder", value=str(Path.home() / "splat2sim_projects/scene1")).classes("w-full")
                video = ui.input("Input video (.mp4)").classes("w-full")
                lidar = ui.input("Optional lidar point cloud (.ply/.las/.pcd)").classes("w-full")
                preset = ui.select({"outdoor": "Outdoor (scene)", "object": "Single object"},
                                   value="outdoor", label="Preset")

                def create_or_open():
                    root = Path(folder.value).expanduser()
                    try:
                        if (root / "project.yaml").exists():
                            p = Project(root)
                            ui.notify(f"Opened existing project: {root}")
                        else:
                            p = Project.create(root, root.name, preset.value)
                            ui.notify(f"Project created: {root}")
                        if video.value:
                            p.cfg.ingest.video = str(Path(video.value).expanduser())
                        if lidar.value:
                            p.cfg.ingest.lidar = str(Path(lidar.value).expanduser())
                        p.save()
                        state["project"] = p
                        refresh_status()
                        stepper.next()
                    except Exception as e:
                        ui.notify(str(e), type="negative")

                ui.button("Create / Open project", on_click=create_or_open, icon="folder")

            # -------------------------------------------------- pipeline
            with ui.step("Pipeline"):
                status_rows = {}
                with ui.column().classes("w-full"):
                    for s in STEPS:
                        with ui.row().classes("items-center"):
                            status_rows[s] = ui.icon("radio_button_unchecked")
                            ui.label(STEP_LABELS[s])
                            ui.button(icon="play_arrow",
                                      on_click=lambda s=s: launch([s])).props("flat dense")
                with ui.row():
                    ui.button("Run everything", icon="rocket_launch",
                              on_click=lambda: launch(STEPS)).props("color=primary")
                    ui.button("Next →", on_click=stepper.next).props("flat")
                progress = ui.linear_progress(show_value=False).props("indeterminate").classes("w-full")
                progress.visible = False
                log_area = ui.log(max_lines=400).classes("w-full h-64 font-mono text-xs")

                def refresh_status():
                    p: Project = state["project"]
                    if not p:
                        return
                    st = p.status()
                    for s, icon in status_rows.items():
                        icon.props(f"name={'check_circle' if st[s]['done'] else 'radio_button_unchecked'}")
                        icon.classes(replace="text-green-600" if st[s]["done"] else "text-gray-400")

                def launch(steps: list[str]):
                    if state["busy"]:
                        ui.notify("Pipeline already running", type="warning")
                        return
                    p: Project = state["project"]
                    if not p:
                        ui.notify("Create a project first", type="negative")
                        return
                    state["busy"] = True
                    progress.visible = True

                    def worker():
                        from .cli import _dispatch
                        old = runner.log.info

                        def tee(msg, *args):
                            old(msg, *args)
                            try:
                                log_area.push(msg % args if args else str(msg))
                            except Exception:
                                pass
                        runner.log.info = tee
                        try:
                            for s in steps:
                                log_area.push(f"== {STEP_LABELS[s]} ==")
                                _dispatch(p, s)
                            log_area.push("✔ done")
                        except Exception as e:
                            log_area.push(f"ERROR: {e}")
                            log_area.push(traceback.format_exc(limit=3))
                        finally:
                            runner.log.info = old
                            state["busy"] = False
                            progress.visible = False
                            refresh_status()

                    threading.Thread(target=worker, daemon=True).start()

            # ------------------------------------------------ orientation
            with ui.step("Orientation"):
                ui.markdown("The COLMAP scene has an arbitrary orientation. Level it here "
                            "**before** crop and export (the crop box is axis-aligned). "
                            "Rotations are applied consistently to both the splat "
                            "(positions + per-gaussian quaternions) and the geometric mesh.")
                orient_lbl = ui.markdown("")

                def _orient(kind, rot=None):
                    p: Project = state["project"]
                    if not p:
                        return ui.notify("Create a project first", type="negative")
                    import trimesh
                    from .splatops import (align_normal_to_z, load_gaussian_ply, pca_up,
                                           ransac_ground_normal, rot_matrix_xyz,
                                           rotate_gaussians, save_gaussian_ply)
                    st = p._state()
                    ply = st.get("train_splat", {}).get("ply")
                    if not ply:
                        return ui.notify("Run step 3 (splat training) first", type="warning")
                    v, xyz, _ = load_gaussian_ply(Path(ply))
                    R, msg, z0 = None, "", None
                    if kind == "ransac":
                        n, _, cnt = ransac_ground_normal(xyz)
                        R = align_normal_to_z(n)
                        pct = 100 * cnt / min(len(xyz), 30000)
                        msg = (f"✅ **Auto-level (RANSAC)**: dominant plane with {pct:.0f}% inliers "
                               "made horizontal. If it locked onto a wall instead of the ground "
                               "(very vertical scenes), refine manually or try PCA.")
                    elif kind == "pca":
                        R = align_normal_to_z(pca_up(xyz))
                        msg = ("✅ **PCA**: minimum-variance axis aligned to +Z. Reliable for "
                               "spread-out scenes; less so for tall or narrow ones.")
                    elif kind == "manual":
                        R = rot_matrix_xyz(*rot)
                        msg = f"✅ Manual rotation applied ({rot[0]}°, {rot[1]}°, {rot[2]}°)."
                    pivot = xyz.mean(0)
                    if R is not None:
                        xyz = rotate_gaussians(v, R, pivot)
                    if kind == "ground_zero":
                        z0 = float(np.percentile(xyz[:, 2], 5))
                        v["z"] = (xyz[:, 2] - z0).astype("f4")
                        msg = f"✅ Translated: 5th height percentile (≈ ground) now at z=0 (offset {z0:+.2f})."
                    save_gaussian_ply(v, Path(ply))
                    mesh_p = st.get("train_geo", {}).get("mesh")
                    if mesh_p and Path(mesh_p).exists():
                        m = trimesh.load(mesh_p, force="mesh")
                        if R is not None:
                            m.vertices = (m.vertices - pivot) @ R.T + pivot
                        if z0 is not None:
                            m.vertices[:, 2] -= z0
                        m.export(mesh_p)
                        msg += " Mesh rotated consistently."
                    orient_lbl.set_content(msg + " Re-run step 5 to refresh cleanup.")

                with ui.row():
                    ui.button("Auto-level (dominant plane)", icon="auto_fix_high",
                              on_click=lambda: _orient("ransac")).props("color=primary")
                    ui.button("PCA principal axes", icon="align_vertical_bottom",
                              on_click=lambda: _orient("pca"))
                    ui.button("Ground to z=0", icon="vertical_align_bottom",
                              on_click=lambda: _orient("ground_zero"))
                with ui.row():
                    rx = ui.number("rot X (°)", value=0.0, step=0.5)
                    ry = ui.number("rot Y (°)", value=0.0, step=0.5)
                    rz = ui.number("rot Z (°)", value=0.0, step=0.5)
                    ui.button("Apply rotation", icon="360",
                              on_click=lambda: _orient("manual", (float(rx.value), float(ry.value), float(rz.value))))
                ui.button("Next →", on_click=stepper.next).props("flat")

            # -------------------------------------------- crop / cleanup
            with ui.step("Crop & cleanup"):
                ui.markdown("Define the **region of interest** (scene units): it is applied to "
                            "both the splat and the collider mesh. Outside the box only the "
                            "visual background remains.")
                crop_on = ui.switch("Enable crop box")
                with ui.row():
                    cx = ui.number("center X", value=0.0); cy = ui.number("center Y", value=0.0); cz = ui.number("center Z", value=0.0)
                with ui.row():
                    sx = ui.number("size X", value=20.0); sy = ui.number("size Y", value=20.0); sz = ui.number("size Z", value=10.0)
                with ui.row():
                    min_op = ui.number("min opacity", value=0.05, step=0.01)
                    max_sc = ui.number("max gaussian scale", value=2.0, step=0.1)
                    tgt = ui.number("collider face budget", value=200000, step=10000)
                ui.markdown("*Min opacity removes near-transparent dust; max scale removes huge "
                            "blobs (sky/halos); the face budget is the decimation target.*").classes("text-xs")
                with ui.row():
                    f_ext = ui.number("min component extent (0=off)", value=0.0, step=0.1)
                    f_hov = ui.number("max hover above ground (0=off)", value=0.0, step=0.05)
                    f_hme = ui.number("hover filter only below extent", value=2.0, step=0.5)
                ui.markdown("*Component filters: pieces smaller than the extent are removed; small "
                            "pieces floating above the ground beyond the hover distance are removed. "
                            "Extended elevated geometry (canopies, cables) is never touched by the "
                            "hover filter thanks to the extent guard. Hover filter requires the "
                            "ground layer below.*").classes("text-xs")

                bounds_lbl = ui.label("").classes("text-xs text-gray-500")
                scene_holder = ui.column().classes("w-full")

                def _mesh_bounds():
                    import trimesh
                    p: Project = state["project"]
                    meta = p._state().get("train_geo", {})
                    if not meta.get("mesh"):
                        return None
                    m = trimesh.load(meta["mesh"], force="mesh")
                    return m.bounds

                def fit_box():
                    b = _mesh_bounds()
                    if b is None:
                        ui.notify("No mesh yet: run step 4 first", type="warning")
                        return
                    lo, hi = b
                    c = (lo + hi) / 2.0
                    s = (hi - lo) * 1.05
                    cx.value, cy.value, cz.value = [round(float(x), 2) for x in c]
                    sx.value, sy.value, sz.value = [round(float(x), 2) for x in s]
                    crop_on.value = True
                    bounds_lbl.set_text(
                        f"Mesh bounds: min ({lo[0]:.2f}, {lo[1]:.2f}, {lo[2]:.2f})  "
                        f"max ({hi[0]:.2f}, {hi[1]:.2f}, {hi[2]:.2f}) [scene units]")

                def save_cleanup_cfg():
                    p: Project = state["project"]
                    c = p.cfg.cleanup
                    c.crop.enabled = crop_on.value
                    c.crop.center = (cx.value, cy.value, cz.value)
                    c.crop.size = (sx.value, sy.value, sz.value)
                    c.min_opacity = float(min_op.value)
                    c.max_scale = float(max_sc.value)
                    c.target_faces = int(tgt.value)
                    c.min_extent = float(f_ext.value)
                    c.max_hover = float(f_hov.value)
                    c.hover_max_extent = float(f_hme.value)
                    g = p.cfg.ground
                    g.enabled = ground_on.value
                    g.smooth = float(g_smooth.value)
                    g.grid_res = int(g_res.value)
                    g.percentile = float(g_perc.value)
                    g.object_size = float(g_obj.value)
                    g.robust_band = float(g_band.value)
                    p.save()

                def preview():
                    """Splat point cloud + mesh + ground + crop box in one scene."""
                    p: Project = state["project"]
                    st = p._state()
                    scene_holder.clear()
                    with scene_holder:
                        with ui.scene(width=860, height=460).classes("w-full") as sc:
                            splat = st.get("cleanup", {}).get("splat") or \
                                st.get("train_splat", {}).get("ply")
                            if splat and Path(splat).exists():
                                from .splatops import load_gaussian_ply
                                _, xyz, rgb = load_gaussian_ply(Path(splat))
                                idx = np.random.default_rng(0).choice(
                                    len(xyz), min(50000, len(xyz)), replace=False)
                                sc.point_cloud(points=xyz[idx].tolist(),
                                               colors=rgb[idx].tolist(), point_size=0.02)
                            mesh_p = st.get("cleanup", {}).get("mesh") or \
                                st.get("train_geo", {}).get("mesh")
                            if mesh_p and Path(mesh_p).exists():
                                glb = _to_glb(Path(mesh_p), p.dir("clean") / "preview.glb",
                                              color=[160, 160, 165, 255])
                                app.add_static_files("/preview", str(glb.parent))
                                sc.gltf(f"/preview/{glb.name}")
                            gp = st.get("cleanup", {}).get("ground")
                            if gp and Path(gp).exists():
                                gg = _to_glb(Path(gp), p.dir("clean") / "ground.glb",
                                             color=[110, 160, 105, 255])
                                app.add_static_files("/preview", str(gg.parent))
                                sc.gltf(f"/preview/{gg.name}")
                            if crop_on.value:
                                box = sc.box(sx.value, sy.value, sz.value).material("#ff6666", opacity=0.2)
                                box.move(cx.value, cy.value, cz.value)

                def apply_cleanup():
                    save_cleanup_cfg()
                    ui.notify("Running cleanup... watch the logs in the Pipeline step")
                    threading.Thread(target=lambda: _safe("cleanup"), daemon=True).start()

                cleanup_result = ui.markdown("")

                def _safe(step):
                    from .cli import _dispatch
                    try:
                        _dispatch(state["project"], step)
                        cleanup_result.set_content(f"✅ **{step} done.** Refresh the preview.")
                    except Exception as e:
                        cleanup_result.set_content(f"❌ **{step}:** {e}")

                # ---- ground layer controls ----
                ui.separator()
                ground_on = ui.switch("Ground layer — dedicated hole-free terrain collider")
                ui.markdown("*Regular heightfield over the whole XY extent (no holes by "
                            "construction), built from the lowest points of each cell, with "
                            "aggressive smoothing that keeps only the general terrain trend "
                            "(slopes, hills). Enters the asset as a separate collider labeled "
                            "`ground`.*").classes("text-xs")
                with ui.row():
                    g_smooth = ui.number("smoothing σ (cells)", value=4.0, step=0.5)
                    g_res = ui.number("grid resolution", value=120, step=10)
                    g_perc = ui.number("ground percentile", value=5.0, step=1.0)
                with ui.row():
                    g_obj = ui.number("object filter footprint (0=off)", value=0.0, step=0.1)
                    g_band = ui.number("artifact tolerance band (0=off)", value=0.0, step=0.05)
                ui.markdown("*Object filter: localized bumps up to this footprint (small clutter) "
                            "are not terrain and get flattened; extended relief survives. Artifact "
                            "band: cells deviating from a robust reference terrain beyond the band "
                            "(misaligned cloud patches, both pits and bumps) are corrected.*"
                            ).classes("text-xs")

                with ui.row():
                    ui.button("Fit box to mesh", icon="fit_screen", on_click=fit_box)
                    ui.button("3D preview", icon="visibility", on_click=preview)
                    ui.button("Apply cleanup", icon="cleaning_services",
                              on_click=apply_cleanup).props("color=primary")
                    ui.button("Next →", on_click=stepper.next).props("flat")

            # ------------------------------------------------- export
            with ui.step("Export"):
                mode = ui.select({"static": "Static environment (exact mesh collider)",
                                  "dynamic": "Dynamic object (rigid body, convex decomposition)"},
                                 value="static", label="Asset type")
                scale = ui.number("Scale → meters (real ÷ measured in scene units)",
                                  value=1.0, step=0.01)
                label = ui.input("Semantic label (e.g. ground, obstacle)", value="")
                ui.markdown("*The COLMAP scene is not metric: measure a known distance in scene "
                            "units (see the bounds above) and set the ratio. In Isaac Sim: create "
                            "a new stage and drag the .usdz in as a reference — never open it as "
                            "the root stage.*").classes("text-xs")
                result = ui.markdown("")

                def do_export():
                    p: Project = state["project"]
                    p.cfg.export.mode = mode.value
                    p.cfg.export.scale_to_meters = float(scale.value)
                    p.cfg.export.semantic_label = label.value or None
                    p.save()

                    def worker():
                        from .steps.export_usd import export_asset
                        try:
                            out = export_asset(p)
                            result.set_content(
                                f"**Asset ready:** `{out}`\n\n"
                                "Contains the visual splat layer plus invisible, aligned physics "
                                "colliders (structure and, if enabled, ground).")
                        except Exception as e:
                            result.set_content(f"**Export error:** {e}")

                    threading.Thread(target=worker, daemon=True).start()

                ui.button("Export USD/USDZ", icon="rocket", on_click=do_export).props("color=primary")

    ui.run(port=port, title="splat2sim", reload=False, show=False)


def _to_glb(src: Path, dst: Path, color=None) -> Path:
    import trimesh
    m = trimesh.load(src, force="mesh")
    if len(m.faces) > 80000:
        try:
            m = m.simplify_quadric_decimation(face_count=80000)
        except BaseException:
            pass
    if color is not None:
        m.visual.vertex_colors = color
    m.export(dst)
    return dst


if __name__ in {"__main__", "__mp_main__"}:
    main()
