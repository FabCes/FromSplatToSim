"""Project folder layout and resumable pipeline state."""
from __future__ import annotations

import json
import time
from pathlib import Path

from .config import ProjectConfig, preset

STEPS = ["ingest", "poses", "train_splat", "train_geo", "cleanup", "export"]

LAYOUT = {
    "frames": "01_frames",            # extracted video frames
    "colmap": "02_colmap",            # COLMAP workspace (database, sparse, images link)
    "splat": "03_splat",              # trained gaussians (ply/ckpt/usdz from 3dgrut)
    "geo": "04_geo",                  # geometric training + raw mesh
    "clean": "05_clean",              # cleaned splat ply + cleaned mesh
    "out": "06_asset",                # final USD/USDZ asset
    "logs": "logs",
}


class Project:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.cfg_path = self.root / "project.yaml"
        self.state_path = self.root / ".state.json"
        self.cfg = ProjectConfig.load(self.cfg_path) if self.cfg_path.exists() else ProjectConfig()

    # ------------------------------------------------------------ creation
    @classmethod
    def create(cls, root: Path, name: str, kind: str = "outdoor") -> "Project":
        root = Path(root)
        if (root / "project.yaml").exists():
            raise FileExistsError(f"Project already exists: {root}")
        cfg = preset(kind)
        cfg.name = name
        cfg.export.asset_name = name
        p = cls(root)
        p.cfg = cfg
        for d in LAYOUT.values():
            (root / d).mkdir(parents=True, exist_ok=True)
        p.save()
        return p

    def save(self) -> None:
        self.cfg.save(self.cfg_path)

    # ------------------------------------------------------------- paths
    def dir(self, key: str) -> Path:
        d = self.root / LAYOUT[key]
        d.mkdir(parents=True, exist_ok=True)
        return d

    # ------------------------------------------------------------- state
    def _state(self) -> dict:
        if self.state_path.exists():
            return json.loads(self.state_path.read_text())
        return {}

    def mark_done(self, step: str, **meta) -> None:
        s = self._state()
        s[step] = {"done": True, "at": time.strftime("%Y-%m-%d %H:%M:%S"), **meta}
        self.state_path.write_text(json.dumps(s, indent=2))

    def is_done(self, step: str) -> bool:
        return bool(self._state().get(step, {}).get("done"))

    def status(self) -> dict:
        s = self._state()
        return {step: s.get(step, {"done": False}) for step in STEPS}
