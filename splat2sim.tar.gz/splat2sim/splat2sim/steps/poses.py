"""Step 2 — POSES (Structure from Motion).

Runs COLMAP (or GLOMAP for the mapper stage) on the extracted frames and
produces the standard workspace layout that both 3dgrut and 2DGS/PGSR read:

    02_colmap/
      database.db
      images/          (symlink/copy of 01_frames)
      sparse/0/        (cameras.bin, images.bin, points3D.bin)
      lidar.ply        (optional, from ingest)

GPU feature extraction/matching is used when available.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from ..project import Project
from ..utils.run import has_cuda_gpu, log, require, run


def run_sfm(project: Project) -> Path:
    cfg = project.cfg.poses
    colmap = require("colmap")
    ws = project.dir("colmap")
    frames = project.dir("frames")
    if not any(frames.glob("*.jpg")):
        raise RuntimeError("No frames in 01_frames: run the 'ingest' step first")

    images = ws / "images"
    if images.is_symlink() or images.exists():
        if images.is_symlink():
            images.unlink()
        else:
            shutil.rmtree(images)
    images.symlink_to(frames.resolve())

    db = ws / "database.db"
    if db.exists():
        db.unlink()
    sparse = ws / "sparse"
    if sparse.exists():
        shutil.rmtree(sparse)
    sparse.mkdir(parents=True)

    gpu = "1" if (cfg.use_gpu and has_cuda_gpu()) else "0"
    logf = project.dir("logs") / "poses.log"

    run([colmap, "feature_extractor",
         "--database_path", db, "--image_path", images,
         "--ImageReader.camera_model", cfg.camera_model,
         "--ImageReader.single_camera", "1",
         "--SiftExtraction.use_gpu", gpu], log_file=logf)

    matcher = "sequential_matcher" if cfg.matcher == "sequential" else "exhaustive_matcher"
    match_args = [colmap, matcher, "--database_path", db,
                  "--SiftMatching.use_gpu", gpu]
    if cfg.matcher == "sequential":
        # loop detection helps closed trajectories (walking around an object/field)
        match_args += ["--SequentialMatching.loop_detection", "1"]
    run(match_args, log_file=logf)

    if cfg.engine == "glomap" and shutil.which("glomap"):
        run(["glomap", "mapper", "--database_path", db,
             "--image_path", images, "--output_path", sparse], log_file=logf)
    else:
        if cfg.engine == "glomap":
            log.info("glomap not found, using colmap mapper")
        run([colmap, "mapper", "--database_path", db,
             "--image_path", images, "--output_path", sparse], log_file=logf)

    model = sparse / "0"
    if not (model / "cameras.bin").exists():
        raise RuntimeError(
            "COLMAP did not reconstruct a model. Typical causes: footage too "
            "fast/blurry, little overlap between frames, textureless scene. "
            "Try raising ingest.target_frames or capture more slowly.")

    # undistort images for the geometric trainers (2DGS/PGSR expect PINHOLE)
    undist = ws / "undistorted"
    if undist.exists():
        shutil.rmtree(undist)
    run([colmap, "image_undistorter", "--image_path", images,
         "--input_path", model, "--output_path", undist,
         "--output_type", "COLMAP"], log_file=logf)

    # image_undistorter writes the model to undistorted/sparse/, but 3DGS-style
    # trainers (2DGS/PGSR) look for it in undistorted/sparse/0/
    usparse = undist / "sparse"
    if (usparse / "cameras.bin").exists() and not (usparse / "0").exists():
        sub = usparse / "0"
        sub.mkdir()
        for name in ("cameras.bin", "images.bin", "points3D.bin"):
            if (usparse / name).exists():
                (usparse / name).rename(sub / name)

    n_imgs = sum(1 for _ in images.iterdir())
    log.info("SfM complete: %d images registered in %s", n_imgs, model)
    project.mark_done("poses", model=str(model))
    return ws
