"""Step 1 — INGEST.

* Video (.mp4/.mov/...) -> frames with adaptive sampling and blur rejection.
* Optional lidar point cloud -> normalized PLY in meters (used later to
  initialize/anchor the reconstruction and to fix the metric scale).
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import numpy as np

from ..project import Project
from ..utils.run import log, require, run


def _resolve_input(p: Path, project: Project) -> Path:
    """Accept absolute paths, paths relative to the project folder, or to cwd."""
    p = p.expanduser()
    for cand in (p, project.root / p, Path.cwd() / p):
        if cand.exists():
            return cand.resolve()
    raise FileNotFoundError(
        f"'{p}' not found. Use an absolute path or place the file "
        f"in the project folder ({project.root}).")


def _video_info(video: Path) -> dict:
    ffprobe = require("ffprobe")
    out = subprocess.check_output([
        ffprobe, "-v", "quiet", "-print_format", "json",
        "-show_streams", "-select_streams", "v:0", str(video)])
    s = json.loads(out)["streams"][0]
    num, den = (int(x) for x in s.get("avg_frame_rate", "30/1").split("/"))
    fps = num / max(den, 1)
    duration = float(s.get("duration", 0) or 0)
    nframes = int(s.get("nb_frames", 0) or duration * fps)
    return {"fps": fps, "duration": duration, "frames": nframes,
            "width": s.get("width"), "height": s.get("height")}


def extract_frames(project: Project) -> Path:
    cfg = project.cfg.ingest
    if not cfg.video:
        raise ValueError("No video configured (ingest.video)")
    video = _resolve_input(Path(cfg.video), project)

    ffmpeg = require("ffmpeg")
    out_dir = project.dir("frames")
    for f in out_dir.glob("*.jpg"):
        f.unlink()

    info = _video_info(video)
    log.info("Video: %sx%s, %.1fs @ %.1f fps (~%d frames)",
             info["width"], info["height"], info["duration"], info["fps"], info["frames"])

    # sample rate to reach ~2x target, then blur-filter down to target
    total = max(info["frames"], 1)
    step = max(total // (cfg.target_frames * 2), 1)

    run([ffmpeg, "-y", "-i", video,
         "-vf", f"select='not(mod(n\\,{step}))',mpdecimate",
         "-vsync", "vfr", "-q:v", "2",
         str(out_dir / "frame_%05d.jpg")],
        log_file=project.dir("logs") / "ingest.log")

    frames = sorted(out_dir.glob("*.jpg"))
    log.info("Extracted %d frames, filtering the blurriest...", len(frames))
    kept = _blur_filter(frames, cfg.min_sharpness, cfg.target_frames)
    log.info("Kept %d sharp frames in %s", kept, out_dir)
    project.mark_done("ingest", frames=kept)
    return out_dir


def _sharpness(path: Path) -> float:
    """Variance of Laplacian; uses cv2 if available, else PIL fallback."""
    try:
        import cv2
        img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if img is None:
            return 0.0
        small = cv2.resize(img, (0, 0), fx=0.5, fy=0.5)
        return float(cv2.Laplacian(small, cv2.CV_64F).var())
    except ImportError:
        from PIL import Image
        img = np.asarray(Image.open(path).convert("L"), dtype=np.float64)
        img = img[::2, ::2]
        lap = (-4 * img[1:-1, 1:-1] + img[:-2, 1:-1] + img[2:, 1:-1]
               + img[1:-1, :-2] + img[1:-1, 2:])
        return float(lap.var())


def _blur_filter(frames: list[Path], min_sharpness: float, target: int) -> int:
    scores = [(f, _sharpness(f)) for f in frames]
    sharp = [(f, s) for f, s in scores if s >= min_sharpness]
    if not sharp:  # threshold too strict for this footage: keep the best ones
        sharp = sorted(scores, key=lambda x: -x[1])[:target]
    if len(sharp) > target:  # uniform temporal subsample of the sharp set
        idx = np.linspace(0, len(sharp) - 1, target).astype(int)
        keep = {sharp[i][0] for i in idx}
    else:
        keep = {f for f, _ in sharp}
    for f, _ in scores:
        if f not in keep:
            f.unlink()
    return len(keep)


# ------------------------------------------------------------------ lidar
def normalize_lidar(project: Project) -> Path | None:
    """Convert the optional lidar cloud to `02_colmap/lidar.ply` (meters)."""
    cfg = project.cfg.ingest
    if not cfg.lidar:
        return None
    src = _resolve_input(Path(cfg.lidar), project)
    out = project.dir("colmap") / "lidar.ply"
    suffix = src.suffix.lower()
    if suffix in (".ply",):
        import trimesh
        pc = trimesh.load(src)
        pts = np.asarray(pc.vertices, dtype=np.float64) * cfg.lidar_units_to_m
        _write_ply_points(out, pts)
    elif suffix in (".las", ".laz"):
        try:
            import laspy
        except ImportError as e:
            raise RuntimeError("pip install laspy to read .las/.laz files") from e
        las = laspy.read(src)
        pts = np.vstack([las.x, las.y, las.z]).T * cfg.lidar_units_to_m
        _write_ply_points(out, pts)
    elif suffix == ".pcd":
        try:
            import open3d as o3d
        except ImportError as e:
            raise RuntimeError("pip install open3d to read .pcd files") from e
        pc = o3d.io.read_point_cloud(str(src))
        pts = np.asarray(pc.points) * cfg.lidar_units_to_m
        _write_ply_points(out, pts)
    else:
        raise ValueError(f"Unsupported lidar format: {suffix}")
    log.info("Normalized lidar: %s (%d points, meters)", out, len(pts))
    return out


def _write_ply_points(path: Path, pts: np.ndarray) -> None:
    from plyfile import PlyData, PlyElement
    arr = np.zeros(len(pts), dtype=[("x", "f4"), ("y", "f4"), ("z", "f4")])
    arr["x"], arr["y"], arr["z"] = pts[:, 0], pts[:, 1], pts[:, 2]
    PlyData([PlyElement.describe(arr, "vertex")]).write(str(path))
