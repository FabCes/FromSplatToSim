"""Step 6 — EXPORT USD (Isaac Sim ready).

Builds a two-layer asset:

    /World  (Xform, kind=component, Z-up, meters, defaultPrim)
      /World/Visual
        /World/Visual/GaussianSplat     <- payload to 3dgrut native .usdz (if any)
        /World/Visual/PreviewMesh       <- visible mesh fallback (proxy purpose)
      /World/Physics                    <- purpose=guide, invisible to renderer
        /World/Physics/Collider         <- UsdPhysics CollisionAPI (+ RigidBody if dynamic)
      /World/PhysicsScene               <- only for standalone scenes (static mode)

Conventions enforced (Isaac Sim): upAxis=Z, metersPerUnit=1.0.
Static env  -> exact triangle-mesh collider (approximation "none").
Dynamic obj -> RigidBodyAPI + convexDecomposition collider approximation.

Semantic labels are authored in both Isaac formats (UsdSemantics.LabelsAPI
when available, plus the classic Semantics API attributes).
"""
from __future__ import annotations

import shutil
from pathlib import Path

import numpy as np
import trimesh
from pxr import Gf, Kind, Sdf, Usd, UsdGeom, UsdPhysics, UsdUtils

from ..project import Project
from ..utils.run import log


def export_asset(project: Project,
                 splat_usdz: Path | None = None,
                 collider_mesh: Path | None = None,
                 splat_ply: Path | None = None) -> Path:
    cfg = project.cfg.export
    state = project._state()
    out_dir = project.dir("out")

    # resolve inputs from previous steps if not given explicitly
    if splat_usdz is None:
        u = state.get("train_splat", {}).get("usdz")
        splat_usdz = Path(u) if u else None
    if collider_mesh is None:
        m = state.get("cleanup", {}).get("mesh")
        collider_mesh = Path(m) if m else None
    if splat_ply is None:
        p = state.get("cleanup", {}).get("splat")
        splat_ply = Path(p) if p else None
    g = state.get("cleanup", {}).get("ground")
    ground_ply = Path(g) if g else None

    if splat_usdz is None and splat_ply is not None:
        splat_usdz = _try_ply_to_usdz(splat_ply, out_dir)

    asset = out_dir / f"{cfg.asset_name}.usda"
    if asset.exists():
        asset.unlink()
    stage = Usd.Stage.CreateNew(str(asset))
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)

    world = UsdGeom.Xform.Define(stage, "/World")
    stage.SetDefaultPrim(world.GetPrim())
    Usd.ModelAPI(world.GetPrim()).SetKind(Kind.Tokens.component)

    # global calibration transform: metric scale + up-axis fix
    xf = UsdGeom.XformCommonAPI(world)
    if cfg.scale_to_meters != 1.0:
        s = float(cfg.scale_to_meters)
        xf.SetScale(Gf.Vec3f(s, s, s))
    if any(cfg.z_up_rotation_deg):
        xf.SetRotate(Gf.Vec3f(*[float(a) for a in cfg.z_up_rotation_deg]))

    # ---------------------------------------------------------- visual
    visual = UsdGeom.Xform.Define(stage, "/World/Visual")
    if splat_usdz and Path(splat_usdz).exists():
        local = out_dir / Path(splat_usdz).name
        if Path(splat_usdz).resolve() != local.resolve():
            shutil.copy2(splat_usdz, local)
        splat = UsdGeom.Xform.Define(stage, "/World/Visual/GaussianSplat")
        splat.GetPrim().GetPayloads().AddPayload(f"./{local.name}")
        log.info("Visual layer: gaussian splat %s (payload)", local.name)
    if collider_mesh and Path(collider_mesh).exists():
        # visible preview/proxy mesh: useful in usdview & as RTX-lidar target
        pv = _author_mesh(stage, "/World/Visual/PreviewMesh", collider_mesh)
        UsdGeom.Imageable(pv).GetPurposeAttr().Set(
            UsdGeom.Tokens.proxy if splat_usdz else UsdGeom.Tokens.default_)
        pv.GetDisplayColorAttr().Set([Gf.Vec3f(0.6, 0.6, 0.62)])

    # --------------------------------------------------------- physics
    if collider_mesh and Path(collider_mesh).exists():
        phys_root = UsdGeom.Xform.Define(stage, "/World/Physics")
        mesh = _author_mesh(stage, "/World/Physics/Collider", collider_mesh)
        img = UsdGeom.Imageable(mesh)
        img.GetPurposeAttr().Set(UsdGeom.Tokens.guide)   # invisible to render
        img.GetVisibilityAttr().Set(UsdGeom.Tokens.invisible)

        UsdPhysics.CollisionAPI.Apply(mesh.GetPrim())
        mesh_col = UsdPhysics.MeshCollisionAPI.Apply(mesh.GetPrim())
        if cfg.mode == "dynamic":
            UsdPhysics.RigidBodyAPI.Apply(world.GetPrim())
            UsdPhysics.MassAPI.Apply(world.GetPrim())
            mesh_col.GetApproximationAttr().Set(UsdPhysics.Tokens.convexDecomposition)
        else:
            mesh_col.GetApproximationAttr().Set(UsdPhysics.Tokens.none)  # exact
        log.info("Physics layer: collider %s (%s)", Path(collider_mesh).name,
                 "convexDecomposition" if cfg.mode == "dynamic" else "exact mesh")
    else:
        log.info("WARNING: no collider mesh -> visual-only asset, no physics")

    if ground_ply and ground_ply.exists():
        gp = _author_mesh(stage, "/World/Visual/GroundPreview", ground_ply)
        UsdGeom.Imageable(gp).GetPurposeAttr().Set(
            UsdGeom.Tokens.proxy if splat_usdz else UsdGeom.Tokens.default_)
        gp.GetDisplayColorAttr().Set([Gf.Vec3f(0.45, 0.62, 0.42)])
        gc = _author_mesh(stage, "/World/Physics/GroundCollider", ground_ply)
        img = UsdGeom.Imageable(gc)
        img.GetPurposeAttr().Set(UsdGeom.Tokens.guide)
        img.GetVisibilityAttr().Set(UsdGeom.Tokens.invisible)
        UsdPhysics.CollisionAPI.Apply(gc.GetPrim())
        UsdPhysics.MeshCollisionAPI.Apply(gc.GetPrim()).GetApproximationAttr().Set(
            UsdPhysics.Tokens.none)
        _label(gc.GetPrim(), "ground")
        log.info("Ground layer: dedicated hole-free collider (labeled 'ground')")

    if cfg.mode == "static":
        UsdPhysics.Scene.Define(stage, "/World/PhysicsScene")

    if cfg.semantic_label:
        _label(world.GetPrim(), cfg.semantic_label)

    stage.GetRootLayer().customLayerData = {
        "generator": "splat2sim",
        "mode": cfg.mode,
        "scale_to_meters": float(cfg.scale_to_meters),
    }
    stage.Save()

    final = asset
    if cfg.package_usdz:
        usdz = out_dir / f"{cfg.asset_name}.usdz"
        ok = UsdUtils.CreateNewUsdzPackage(Sdf.AssetPath(str(asset)), str(usdz))
        if ok:
            final = usdz
            log.info("USDZ package: %s", usdz)
        else:
            log.info("usdz packaging failed, delivering the .usda")

    project.mark_done("export", asset=str(final))
    log.info("Asset ready for Isaac Sim: %s", final)
    return final


# ------------------------------------------------------------------ mesh
def _author_mesh(stage: Usd.Stage, path: str, mesh_file: Path) -> UsdGeom.Mesh:
    from pxr import Vt
    m = trimesh.load(mesh_file, force="mesh")
    usd_mesh = UsdGeom.Mesh.Define(stage, path)
    usd_mesh.GetPointsAttr().Set(Vt.Vec3fArray.FromNumpy(np.ascontiguousarray(m.vertices, dtype=np.float32)))
    usd_mesh.GetFaceVertexCountsAttr().Set(Vt.IntArray.FromNumpy(np.full(len(m.faces), 3, dtype=np.int32)))
    usd_mesh.GetFaceVertexIndicesAttr().Set(Vt.IntArray.FromNumpy(np.ascontiguousarray(m.faces.flatten(), dtype=np.int32)))
    usd_mesh.GetSubdivisionSchemeAttr().Set(UsdGeom.Tokens.none)
    lo, hi = m.bounds.astype(float)
    usd_mesh.GetExtentAttr().Set([Gf.Vec3f(*map(float, lo)), Gf.Vec3f(*map(float, hi))])
    if m.vertex_normals is not None and len(m.vertex_normals) == len(m.vertices):
        usd_mesh.GetNormalsAttr().Set(Vt.Vec3fArray.FromNumpy(np.ascontiguousarray(m.vertex_normals, dtype=np.float32)))
        usd_mesh.SetNormalsInterpolation(UsdGeom.Tokens.vertex)
    return usd_mesh


# ------------------------------------------------------------- semantics
def _label(prim: Usd.Prim, label: str) -> None:
    try:  # USD >= 24.11
        from pxr import UsdSemantics
        api = UsdSemantics.LabelsAPI.Apply(prim, "class")
        api.GetLabelsAttr().Set([label])
    except ImportError:
        pass
    # classic Isaac/Replicator format: the schema plugin ships with Isaac, not
    # with usd-core, so we author the applied-schema token + attributes raw.
    prim.AddAppliedSchema("SemanticsAPI:class_label")
    prim.CreateAttribute("semantic:class_label:params:semanticType",
                         Sdf.ValueTypeNames.String).Set("class")
    prim.CreateAttribute("semantic:class_label:params:semanticData",
                         Sdf.ValueTypeNames.String).Set(label)


# ------------------------------------------------- optional 3dgrut convert
def _try_ply_to_usdz(ply: Path, out_dir: Path) -> Path | None:
    """Convert a gaussian PLY to the 3dgrut USDZ splat schema, if the repo
    is available. Falls back to None (mesh-only visual) otherwise."""
    import os
    import subprocess
    import sys
    repo = Path(os.environ.get("SPLAT2SIM_3DGRUT",
                Path(__file__).resolve().parents[2] / "third_party/3dgrut"))
    if not repo.exists():
        log.info("3dgrut not found: cannot convert PLY -> splat USDZ")
        return None
    py = repo / ".venv/bin/python"
    py = str(py) if py.exists() else sys.executable
    out = out_dir / (ply.stem + ".usdz")
    try:
        subprocess.run([py, "-m", "threedgrut.export.scripts.ply_to_usd",
                        str(ply), "--output_file", str(out)],
                       cwd=repo, check=True, capture_output=True, text=True)
        return out if out.exists() else None
    except subprocess.CalledProcessError as e:
        log.info("ply_to_usd failed: %s", (e.stderr or "")[-400:])
        return None
