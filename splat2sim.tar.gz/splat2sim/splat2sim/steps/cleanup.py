"""Step 5 — CLEANUP.

Applies the SAME region of interest to both layers so visual and physics
stay coherent:

* Splat (3DGS .ply): opacity threshold, oversized-gaussian removal (sky
  blobs), statistical outlier removal (floaters), optional crop box.
* Mesh: crop box clip, spurious component removal, hole filling,
  decimation to a collider-friendly triangle budget.
"""
from __future__ import annotations

import numpy as np
import trimesh
from pathlib import Path
from plyfile import PlyData, PlyElement

from ..config import CropBox
from ..project import Project
from ..utils.run import log


# ---------------------------------------------------------------- splat
def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def clean_splat(project: Project, src: Path | None = None) -> Path:
    cfg = project.cfg.cleanup
    src = src or _splat_ply(project)
    out = project.dir("clean") / "splat_clean.ply"

    ply = PlyData.read(str(src))
    v = ply["vertex"].data
    n0 = len(v)
    keep = np.ones(n0, dtype=bool)
    names = v.dtype.names

    xyz = np.vstack([v["x"], v["y"], v["z"]]).T.astype(np.float64)

    if "opacity" in names and cfg.min_opacity > 0:
        keep &= sigmoid(np.asarray(v["opacity"], dtype=np.float64)) >= cfg.min_opacity
    if all(f"scale_{i}" in names for i in range(3)) and cfg.max_scale > 0:
        scales = np.exp(np.vstack([v[f"scale_{i}"] for i in range(3)]).T.astype(np.float64))
        keep &= scales.max(axis=1) <= cfg.max_scale
    if cfg.crop.enabled:
        keep &= _in_box(xyz, cfg.crop)
    if cfg.outlier_neighbors > 0 and keep.sum() > cfg.outlier_neighbors + 1:
        keep_idx = np.flatnonzero(keep)
        inliers = _statistical_inliers(xyz[keep_idx], cfg.outlier_neighbors, cfg.outlier_std)
        mask = np.zeros(n0, dtype=bool)
        mask[keep_idx[inliers]] = True
        keep = mask

    el = PlyElement.describe(v[keep], "vertex")
    PlyData([el]).write(str(out))
    log.info("Splat cleanup: %d -> %d gaussians (-%.1f%%)",
             n0, keep.sum(), 100 * (1 - keep.sum() / max(n0, 1)))
    return out


def _splat_ply(project: Project) -> Path:
    meta = project._state().get("train_splat", {})
    if meta.get("ply"):
        return Path(meta["ply"])
    cands = list(project.dir("splat").rglob("*.ply"))
    if not cands:
        raise RuntimeError("No splat .ply found: run 'train_splat' first")
    return max(cands, key=lambda p: p.stat().st_mtime)


def _in_box(xyz: np.ndarray, box: CropBox) -> np.ndarray:
    c = np.asarray(box.center, dtype=np.float64)
    h = np.asarray(box.size, dtype=np.float64) / 2.0
    return np.all(np.abs(xyz - c) <= h, axis=1)


def _statistical_inliers(pts: np.ndarray, k: int, n_std: float) -> np.ndarray:
    """Indices of points whose mean k-NN distance is within n_std sigmas.
    Uses scipy cKDTree when available, otherwise a grid-subsampled fallback."""
    try:
        from scipy.spatial import cKDTree
        tree = cKDTree(pts)
        d, _ = tree.query(pts, k=k + 1)
        mean_d = d[:, 1:].mean(axis=1)
    except ImportError:
        # coarse fallback: distance to random subset
        sub = pts[np.random.default_rng(0).choice(len(pts), min(5000, len(pts)), replace=False)]
        d = np.linalg.norm(pts[:, None, :] - sub[None, :50, :], axis=2)
        mean_d = np.sort(d, axis=1)[:, :k].mean(axis=1)
    mu, sigma = mean_d.mean(), mean_d.std()
    return np.flatnonzero(mean_d <= mu + n_std * sigma)


# ----------------------------------------------------------------- mesh
def clean_mesh(project: Project, src: Path | None = None) -> Path | None:
    cfg = project.cfg.cleanup
    if src is None:
        meta = project._state().get("train_geo", {})
        if not meta.get("mesh"):
            log.info("No geometric mesh: skipping mesh cleanup")
            return None
        src = Path(meta["mesh"])
    out = project.dir("clean") / "collider.ply"

    mesh = trimesh.load(src, force="mesh")
    log.info("Input mesh: %d faces, %d vertices", len(mesh.faces), len(mesh.vertices))

    if cfg.crop.enabled:
        c = np.asarray(cfg.crop.center, dtype=np.float64)
        s = np.asarray(cfg.crop.size, dtype=np.float64)
        mesh = _clip_to_box(mesh, c, s)

    # remove spurious disconnected components (classic splat-mesh artifacts)
    comps = mesh.split(only_watertight=False)
    if len(comps) > 1:
        comps = [m for m in comps if len(m.faces) >= cfg.min_component_faces]
        comps.sort(key=lambda m: -len(m.faces))
        if cfg.keep_components > 0:
            comps = comps[:cfg.keep_components]
        if comps:
            mesh = trimesh.util.concatenate(comps)
        log.info("Components kept: %d", len(comps))

    mesh.update_faces(mesh.nondegenerate_faces())
    mesh.remove_unreferenced_vertices()
    if cfg.fill_holes:
        trimesh.repair.fill_holes(mesh)

    if cfg.target_faces > 0 and len(mesh.faces) > cfg.target_faces:
        try:
            mesh = mesh.simplify_quadric_decimation(face_count=cfg.target_faces)
            log.info("Decimated to %d faces", len(mesh.faces))
        except BaseException as e:  # fast-simplification not installed
            log.info("Decimation skipped (%s). pip install fast-simplification", e)

    mesh.export(out)
    log.info("Clean collider mesh: %s (%d faces)", out, len(mesh.faces))
    return out


def _clip_to_box(mesh: trimesh.Trimesh, center: np.ndarray, size: np.ndarray) -> trimesh.Trimesh:
    """Clip with 6 slice planes (robust also on non-watertight meshes)."""
    h = size / 2.0
    m = mesh
    for axis in range(3):
        for sign in (1.0, -1.0):
            origin = center.copy()
            origin[axis] += sign * h[axis]
            normal = np.zeros(3)
            normal[axis] = -sign
            m = m.slice_plane(plane_origin=origin, plane_normal=normal)
            if m is None or len(m.faces) == 0:
                lo, hi = mesh.bounds
                raise RuntimeError(
                    "The crop box does not intersect the mesh. Mesh bounds: "
                    f"min ({lo[0]:.2f}, {lo[1]:.2f}, {lo[2]:.2f}), "
                    f"max ({hi[0]:.2f}, {hi[1]:.2f}, {hi[2]:.2f}). "
                    "Use 'Fit to mesh' in the GUI or fix cleanup.crop in project.yaml.")
    return m


def build_ground_layer(project: Project, splat_ply: Path):
    """Optional terrain heightfield built from the cleaned splat."""
    gcfg = project.cfg.ground
    if not gcfg.enabled:
        return None
    from ..splatops import build_ground, load_gaussian_ply
    _, xyz, _ = load_gaussian_ply(splat_ply)
    ground = build_ground(xyz, grid_res=gcfg.grid_res, percentile=gcfg.percentile,
                          smooth=gcfg.smooth, object_size=gcfg.object_size,
                          robust_band=gcfg.robust_band)
    dst = project.dir("clean") / "ground.ply"
    ground.export(dst)
    log.info("Ground layer: %s (%d triangles)", dst, len(ground.faces))
    return dst


def run_cleanup(project: Project) -> dict:
    splat = clean_splat(project)
    ground = build_ground_layer(project, splat)
    mesh = clean_mesh(project)
    # component artifact filters (extent + floating, canopy-safe)
    ccfg = project.cfg.cleanup
    if mesh and (ccfg.min_extent > 0 or (ccfg.max_hover > 0 and ground)):
        import trimesh
        from ..splatops import filter_components
        m = trimesh.load(mesh, force="mesh")
        g = trimesh.load(ground, force="mesh") if ground else None
        m = filter_components(m, min_extent=ccfg.min_extent, ground=g,
                              max_hover=ccfg.max_hover,
                              hover_max_extent=ccfg.hover_max_extent)
        m.export(mesh)
    project.mark_done("cleanup", splat=str(splat), mesh=str(mesh) if mesh else None,
                      ground=str(ground) if ground else None)
    return {"splat": splat, "mesh": mesh, "ground": ground}
