"""Steps 3 & 4 — TRAINING.

Two parallel branches share the same COLMAP workspace:

* train_splat  -> 3dgrut  -> visual gaussians (.ply + native Isaac-ready .usdz)
* train_geo    -> 2DGS or PGSR -> geometrically-accurate mesh for the collider

External repos are expected under `third_party/` (installed by install.sh);
their location can be overridden with the env vars SPLAT2SIM_3DGRUT,
SPLAT2SIM_2DGS, SPLAT2SIM_PGSR.
"""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

from ..project import Project
from ..utils.run import log, run

REPO_ROOT = Path(__file__).resolve().parents[2]
THIRD_PARTY = REPO_ROOT / "third_party"


def _repo(env: str, default: str) -> Path:
    p = Path(os.environ.get(env, THIRD_PARTY / default))
    if not p.exists():
        raise RuntimeError(
            f"Repo '{default}' not found at {p}. Run ./install.sh "
            f"or set {env}=/path/to/repo")
    return p


def _repo_python(repo: Path) -> str:
    """Prefer the repo's own venv (created by its install scripts)."""
    for cand in (repo / ".venv/bin/python", repo / "venv/bin/python"):
        if cand.exists():
            return str(cand)
    return sys.executable


def _find_cuda_home() -> Path | None:
    """Modern CUDA toolkit: /usr/local/cuda-13/12.x/11.8, then CUDA_HOME."""
    import glob
    cands = sorted(glob.glob("/usr/local/cuda-13*"))[::-1] + \
        sorted(glob.glob("/usr/local/cuda-12*"))[::-1] + \
        ["/usr/local/cuda-11.8", "/usr/local/cuda", os.environ.get("CUDA_HOME", "")]
    for c in cands:
        if c and (Path(c) / "bin/nvcc").exists():
            return Path(c)
    return None


def _repo_env(repo: Path) -> dict:
    """Environment equivalent to activating the repo venv (slangc on PATH) with
    the right CUDA toolkit first, so JIT compilation does not pick up an old
    system nvcc."""
    env = {}
    path = os.environ.get("PATH", "")
    vbin = repo / ".venv/bin"
    if vbin.exists():
        path = f"{vbin}:{path}"
        env["VIRTUAL_ENV"] = str(repo / ".venv")
    cuda = _find_cuda_home()
    if cuda:
        path = f"{cuda / 'bin'}:{path}"
        env["CUDA_HOME"] = str(cuda)
        env["CUDA_PATH"] = str(cuda)
        env["LD_LIBRARY_PATH"] = f"{cuda / 'lib64'}:{os.environ.get('LD_LIBRARY_PATH', '')}"
    env["PATH"] = path
    return env


# ---------------------------------------------------------------- 3dgrut
def train_splat(project: Project) -> Path:
    cfg = project.cfg.splat
    ws = project.dir("colmap")
    out = project.dir("splat")
    repo = _repo("SPLAT2SIM_3DGRUT", "3dgrut")

    args = [_repo_python(repo), "train.py",
            "--config-name", cfg.config_name,
            f"path={ws}",
            f"out_dir={out}",
            f"experiment_name={project.cfg.name}",
            f"n_iterations={cfg.iterations}",
            "export_ply.enabled=true"]
    if cfg.export_usdz:
        # current 3dgrut key (was export_usdz in earlier versions);
        # format=standard = ParticleField3DGaussianSplat schema for Isaac Sim
        args += ["export_usd.enabled=true", "export_usd.format=standard"]
    args += cfg.extra_args

    run(args, cwd=repo, log_file=project.dir("logs") / "train_splat.log",
        env=_repo_env(repo))

    ply = _find_latest(out, "*.ply")
    usdz = _find_latest(out, "*.usdz")
    if not ply:
        raise RuntimeError(f"3dgrut training finished but no .ply found in {out}")
    log.info("Splat: %s%s", ply, f" | native usdz: {usdz}" if usdz else "")
    project.mark_done("train_splat", ply=str(ply), usdz=str(usdz) if usdz else None)
    return ply


# ------------------------------------------------------------- 2DGS/PGSR
def train_geo(project: Project) -> Path | None:
    cfg = project.cfg.geo
    if cfg.engine == "none":
        log.info("train_geo skipped (geo.engine=none): no collider mesh")
        project.mark_done("train_geo", mesh=None)
        return None

    if cfg.engine == "gaussians":
        # mesh straight from the trained splat: no second GPU training pass
        from ..splatops import mesh_from_gaussians
        meta = project._state().get("train_splat", {})
        ply = meta.get("ply")
        if not ply:
            raise RuntimeError("geo.engine=gaussians requires 'train_splat' to be done")
        mesh = mesh_from_gaussians(Path(ply), grid_res=cfg.grid_res, iso=cfg.iso)
        dst = project.dir("geo") / "mesh_raw.ply"
        mesh.export(dst)
        log.info("Geometric mesh (from gaussians): %s", dst)
        project.mark_done("train_geo", mesh=str(dst))
        return dst

    ws = project.dir("colmap") / "undistorted"
    out = project.dir("geo")

    if cfg.engine == "2dgs":
        repo = _repo("SPLAT2SIM_2DGS", "2d-gaussian-splatting")
        py = _repo_python(repo)
        model_dir = out / "2dgs"
        trained = (model_dir / "point_cloud").exists()
        if trained:
            log.info("Existing 2DGS checkpoint: skipping training, extracting the mesh only")
        else:
            run([py, "train.py", "-s", ws, "-m", model_dir,
                 "--iterations", str(cfg.iterations), *cfg.extra_args],
                cwd=repo, log_file=project.dir("logs") / "train_geo.log",
                env=_repo_env(repo))
        run([py, "render.py", "-s", ws, "-m", model_dir,
             "--depth_trunc", str(cfg.depth_trunc),
             "--voxel_size", str(cfg.tsdf_voxel),
             "--sdf_trunc", str(cfg.tsdf_voxel * 4),
             "--skip_test", "--skip_train", "--mesh_res", "1024"],
            cwd=repo, log_file=project.dir("logs") / "train_geo.log",
            env=_repo_env(repo))
        mesh = _find_latest(model_dir, "*.ply", contains="fuse")
    elif cfg.engine == "pgsr":
        repo = _repo("SPLAT2SIM_PGSR", "PGSR")
        py = _repo_python(repo)
        model_dir = out / "pgsr"
        run([py, "train.py", "-s", ws, "-m", model_dir,
             "--iterations", str(cfg.iterations), *cfg.extra_args],
            cwd=repo, log_file=project.dir("logs") / "train_geo.log")
        run([py, "render.py", "-s", ws, "-m", model_dir,
             "--max_depth", str(cfg.depth_trunc),
             "--voxel_size", str(cfg.tsdf_voxel)],
            cwd=repo, log_file=project.dir("logs") / "train_geo.log")
        mesh = _find_latest(model_dir, "*.ply", contains="tsdf") or \
            _find_latest(model_dir, "*.ply", contains="fuse")
    else:
        raise ValueError(f"unknown geo.engine: {cfg.engine}")

    if not mesh:
        raise RuntimeError(f"Geometry training finished but no mesh found in {out}")
    dst = out / "mesh_raw.ply"
    shutil.copy2(mesh, dst)
    log.info("Geometric mesh: %s", dst)
    project.mark_done("train_geo", mesh=str(dst))
    return dst


def _find_latest(root: Path, pattern: str, contains: str = "") -> Path | None:
    cands = [p for p in root.rglob(pattern) if contains in p.name]
    return max(cands, key=lambda p: p.stat().st_mtime) if cands else None
