"""splat2sim LITE — pulizia e ritaglio di gaussian splat con export USDZ.

Flusso: cartella COLMAP esistente (o un .ply gia' addestrato) ->
[training 3dgrut opzionale] -> pulizia con parametri spiegati ->
anteprima 3D prima/dopo con crop box -> export USDZ (schema Isaac).

Nessuna mesh, nessuna fisica: solo lo splat visivo.
"""
from __future__ import annotations

import os
import threading
from pathlib import Path

import numpy as np
from nicegui import ui
from plyfile import PlyData, PlyElement

from .steps.cleanup import sigmoid, _statistical_inliers
from .utils.run import log, run

state: dict = {"raw_ply": None, "clean_ply": None, "xyz": None, "rgb": None,
               "keep": None, "busy": False}

# ---------------------------------------------------------------- helpers
SH_C0 = 0.28209479177387814


def load_gaussians(ply_path: Path):
    ply = PlyData.read(str(ply_path))
    v = ply["vertex"].data
    xyz = np.vstack([v["x"], v["y"], v["z"]]).T.astype(np.float64)
    if all(f"f_dc_{i}" in v.dtype.names for i in range(3)):
        dc = np.vstack([v[f"f_dc_{i}"] for i in range(3)]).T
        rgb = np.clip(0.5 + SH_C0 * dc, 0, 1)
    else:
        rgb = np.full((len(xyz), 3), 0.6)
    return v, xyz, rgb


def compute_keep(v, xyz, *, min_opacity, max_scale, out_k, out_std, crop):
    keep = np.ones(len(xyz), dtype=bool)
    names = v.dtype.names
    if "opacity" in names and min_opacity > 0:
        keep &= sigmoid(np.asarray(v["opacity"], dtype=np.float64)) >= min_opacity
    if all(f"scale_{i}" in names for i in range(3)) and max_scale > 0:
        s = np.exp(np.vstack([v[f"scale_{i}"] for i in range(3)]).T.astype(np.float64))
        keep &= s.max(axis=1) <= max_scale
    if crop is not None:
        c, h = np.asarray(crop[0]), np.asarray(crop[1]) / 2.0
        keep &= np.all(np.abs(xyz - c) <= h, axis=1)
    if out_k > 0 and keep.sum() > out_k + 1:
        idx = np.flatnonzero(keep)
        inl = _statistical_inliers(xyz[idx], int(out_k), float(out_std))
        m = np.zeros(len(xyz), dtype=bool)
        m[idx[inl]] = True
        keep = m
    return keep


def save_filtered(v, keep, dst: Path):
    PlyData([PlyElement.describe(v[keep], "vertex")]).write(str(dst))


def find_3dgrut() -> Path | None:
    p = Path(os.environ.get("SPLAT2SIM_3DGRUT",
             Path(__file__).resolve().parents[1] / "third_party/3dgrut"))
    return p if p.exists() else None


def repo_env(repo: Path) -> dict:
    import glob
    env = {}
    path = os.environ.get("PATH", "")
    if (repo / ".venv/bin").exists():
        path = f"{repo / '.venv/bin'}:{path}"
    for d in sorted(glob.glob("/usr/local/cuda-13*"))[::-1] + \
            sorted(glob.glob("/usr/local/cuda-12*"))[::-1] + ["/usr/local/cuda"]:
        if (Path(d) / "bin/nvcc").exists():
            path = f"{Path(d) / 'bin'}:{path}"
            env["CUDA_HOME"] = d
            break
    env["PATH"] = path
    return env


# -------------------------------------------------------------------- GUI
def main(port: int = 8081) -> None:
    @ui.page("/")
    def index():
        ui.markdown("## splat2sim **lite** — COLMAP → splat pulito → USDZ")
        ui.markdown("Pipeline visiva senza mesh/collisioni: training (opzionale), "
                    "pulizia parametrica, anteprima 3D, export USDZ per Isaac Sim.")

        # ------------------------------------------------------ input
        with ui.card().classes("w-full"):
            ui.label("1 · Input").classes("text-lg font-bold")
            colmap_dir = ui.input("Cartella COLMAP (contiene images/ e sparse/0/)",
                                  value="").classes("w-full")
            ply_in = ui.input("...oppure .ply gia' addestrato (salta il training)",
                              value="").classes("w-full")
            out_dir = ui.input("Cartella di output", value=str(Path.home() / "splatlite_out")).classes("w-full")
            iters = ui.number("Iterazioni training", value=30000, min=1000, step=1000)
            train_log = ui.log(max_lines=200).classes("w-full h-40 font-mono text-xs")
            status = ui.markdown("")

            def do_train():
                if state["busy"]:
                    return ui.notify("Operazione in corso", type="warning")
                cm = Path(colmap_dir.value).expanduser()
                if not (cm / "sparse").exists():
                    return ui.notify("Cartella COLMAP non valida (manca sparse/)", type="negative")
                repo = find_3dgrut()
                if repo is None:
                    return ui.notify("3dgrut non trovato in third_party/ (esegui install.sh)", type="negative")
                out = Path(out_dir.value).expanduser(); out.mkdir(parents=True, exist_ok=True)
                state["busy"] = True

                def worker():
                    try:
                        py = repo / ".venv/bin/python"
                        run([str(py if py.exists() else "python3"), "train.py",
                             "--config-name", "apps/colmap_3dgut.yaml",
                             f"path={cm}", f"out_dir={out}", "experiment_name=lite",
                             f"n_iterations={int(iters.value)}",
                             "export_ply.enabled=true"],
                            cwd=repo, env=repo_env(repo),
                            on_line=lambda l: train_log.push(l))
                        plys = sorted(out.rglob("export_last.ply"),
                                      key=lambda p: p.stat().st_mtime)
                        if plys:
                            _load(plys[-1])
                            status.set_content(f"✅ Training completato: `{plys[-1]}` — vai al punto 2.")
                        else:
                            status.set_content("❌ Training finito ma nessun PLY trovato.")
                    except Exception as e:
                        status.set_content(f"❌ {e}")
                    finally:
                        state["busy"] = False
                threading.Thread(target=worker, daemon=True).start()
                status.set_content("⏳ Training in corso... (log qui sopra)")

            def do_load():
                p = Path(ply_in.value).expanduser()
                if not p.exists():
                    return ui.notify("File .ply non trovato", type="negative")
                _load(p)
                status.set_content(f"✅ Caricato `{p.name}`: {len(state['xyz'])} gaussiane — vai al punto 2.")

            def _load(p: Path):
                v, xyz, rgb = load_gaussians(p)
                state.update(raw_ply=p, v=v, xyz=xyz, rgb=rgb, keep=np.ones(len(xyz), bool))
                lo, hi = xyz.min(0), xyz.max(0)
                bounds_lbl.set_text(
                    f"{len(xyz)} gaussiane | bounds min ({lo[0]:.1f}, {lo[1]:.1f}, {lo[2]:.1f}) "
                    f"max ({hi[0]:.1f}, {hi[1]:.1f}, {hi[2]:.1f}) [unita' scena COLMAP]")

            with ui.row():
                ui.button("Addestra da COLMAP", icon="model_training", on_click=do_train).props("color=primary")
                ui.button("Carica .ply esistente", icon="folder_open", on_click=do_load)

        # ---------------------------------------------------- cleanup
        with ui.card().classes("w-full"):
            ui.label("2 · Pulizia").classes("text-lg font-bold")
            bounds_lbl = ui.label("").classes("text-xs text-gray-500")

            with ui.row().classes("items-center"):
                min_op = ui.slider(min=0.0, max=0.5, step=0.01, value=0.05).classes("w-64")
                ui.label().bind_text_from(min_op, "value", lambda v: f"Opacità minima: {v:.2f}")
            ui.markdown("*Elimina le gaussiane quasi trasparenti. Sono \"polvere\" residua del "
                        "training: alzando il valore rimuovi più rumore, ma oltre ~0.2 rischi di "
                        "assottigliare superfici semitrasparenti reali (vetri, fogliame fitto).*").classes("text-xs")

            with ui.row().classes("items-center"):
                max_sc = ui.slider(min=0.0, max=20.0, step=0.1, value=5.0).classes("w-64")
                ui.label().bind_text_from(max_sc, "value", lambda v: f"Scala massima: {v:.1f}")
            ui.markdown("*Elimina le gaussiane più grandi di questo valore (in unità scena — guarda i "
                        "bounds sopra per calibrarti). I \"bloboni\" giganti sono tipicamente cielo o "
                        "aloni: parti alto (≈ 1/4 della scena) e scendi finché spariscono senza bucare "
                        "le superfici. 0 = disattivato.*").classes("text-xs")

            with ui.row().classes("items-center"):
                out_k = ui.slider(min=0, max=40, step=1, value=12).classes("w-64")
                ui.label().bind_text_from(out_k, "value", lambda v: f"Vicini analizzati (k): {int(v)}")
            with ui.row().classes("items-center"):
                out_std = ui.slider(min=0.5, max=4.0, step=0.1, value=2.0).classes("w-64")
                ui.label().bind_text_from(out_std, "value", lambda v: f"Soglia outlier (σ): {v:.1f}")
            ui.markdown("*Rimozione **floater** statistica: per ogni gaussiana misura la distanza media "
                        "dalle k più vicine; chi è più isolato della media + σ deviazioni viene eliminato. "
                        "σ basso (1–1.5) = pulizia aggressiva, σ alto (3+) = conservativa. "
                        "k=0 disattiva il filtro.*").classes("text-xs")

            crop_on = ui.switch("Crop box — tieni solo la regione di interesse")
            ui.markdown("*Tutto ciò che sta fuori dal box viene eliminato. Usa \"Adatta ai bounds\" per "
                        "partire dall'intera scena e poi restringi. Coordinate in unità scena.*").classes("text-xs")
            with ui.row():
                cx = ui.number("centro X", value=0.0); cy = ui.number("centro Y", value=0.0); cz = ui.number("centro Z", value=0.0)
            with ui.row():
                sx = ui.number("dim X", value=10.0); sy = ui.number("dim Y", value=10.0); sz = ui.number("dim Z", value=10.0)

            def fit_bounds():
                if state["xyz"] is None:
                    return ui.notify("Carica prima uno splat", type="warning")
                # bounds robusti (2°-98° percentile) per non farsi ingannare dai floater
                lo = np.percentile(state["xyz"], 2, axis=0)
                hi = np.percentile(state["xyz"], 98, axis=0)
                c, s = (lo + hi) / 2, (hi - lo) * 1.05
                cx.value, cy.value, cz.value = [round(float(x), 2) for x in c]
                sx.value, sy.value, sz.value = [round(float(x), 2) for x in s]
                crop_on.value = True

            result_lbl = ui.markdown("")

            def apply_filters():
                if state["xyz"] is None:
                    return ui.notify("Carica prima uno splat", type="warning")
                crop = ((cx.value, cy.value, cz.value), (sx.value, sy.value, sz.value)) if crop_on.value else None
                keep = compute_keep(state["v"], state["xyz"],
                                    min_opacity=float(min_op.value), max_scale=float(max_sc.value),
                                    out_k=int(out_k.value), out_std=float(out_std.value), crop=crop)
                state["keep"] = keep
                n0, n1 = len(keep), int(keep.sum())
                result_lbl.set_content(
                    f"**{n0} → {n1} gaussiane** (rimosse {n0-n1}, {100*(n0-n1)/max(n0,1):.1f}%). "
                    "Controlla l'anteprima, poi esporta.")
                draw_preview()

            with ui.row():
                ui.button("Adatta ai bounds", icon="fit_screen", on_click=fit_bounds)
                ui.button("Applica filtri", icon="cleaning_services", on_click=apply_filters).props("color=primary")

        # ---------------------------------------------------- preview
        with ui.card().classes("w-full"):
            ui.label("3 · Anteprima").classes("text-lg font-bold")
            ui.markdown("*Punti = centri delle gaussiane (max 60k, campionati). "
                        "Grigio chiaro = gaussiane che verranno rimosse, a colori = quelle tenute. "
                        "Il box rosso è il crop.*").classes("text-xs")
            preview_holder = ui.column().classes("w-full")

            def draw_preview():
                if state["xyz"] is None:
                    return
                xyz, rgb, keep = state["xyz"], state["rgb"], state["keep"]
                n = len(xyz)
                idx = np.random.default_rng(0).choice(n, min(60000, n), replace=False)
                preview_holder.clear()
                with preview_holder:
                    with ui.scene(width=900, height=500).classes("w-full") as sc:
                        ki, ri = idx[keep[idx]], idx[~keep[idx]]
                        if len(ki):
                            sc.point_cloud(points=xyz[ki].tolist(),
                                           colors=rgb[ki].tolist(), point_size=0.02)
                        if len(ri):
                            sc.point_cloud(points=xyz[ri].tolist(),
                                           colors=[[0.85, 0.85, 0.85]] * len(ri), point_size=0.012)
                        if crop_on.value:
                            box = sc.box(sx.value, sy.value, sz.value).material("#ff4444", opacity=0.15)
                            box.move(cx.value, cy.value, cz.value)

            ui.button("Aggiorna anteprima", icon="visibility", on_click=draw_preview)

        # ------------------------------------------------------ export
        with ui.card().classes("w-full"):
            ui.label("4 · Export USDZ").classes("text-lg font-bold")
            ui.markdown("*Salva il PLY pulito e lo converte nello schema splat di Isaac Sim "
                        "(ParticleField3DGaussianSplat) con lo script ufficiale 3dgrut. "
                        "Ricorda: in Isaac referenzia lo .usdz in uno stage nuovo, non aprirlo "
                        "come stage principale.*").classes("text-xs")
            name = ui.input("Nome asset", value="scena_lite")
            export_lbl = ui.markdown("")

            def do_export():
                if state["xyz"] is None or state["keep"] is None:
                    return ui.notify("Applica prima i filtri", type="warning")
                out = Path(out_dir.value).expanduser(); out.mkdir(parents=True, exist_ok=True)
                ply_out = out / f"{name.value}_clean.ply"
                save_filtered(state["v"], state["keep"], ply_out)
                export_lbl.set_content(f"⏳ PLY pulito salvato (`{ply_out}`), converto in USDZ...")

                def worker():
                    repo = find_3dgrut()
                    if repo is None:
                        export_lbl.set_content(f"✅ PLY pulito: `{ply_out}`. "
                                               "⚠️ 3dgrut non trovato: conversione USDZ non disponibile.")
                        return
                    usdz = out / f"{name.value}.usdz"
                    py = repo / ".venv/bin/python"
                    try:
                        run([str(py if py.exists() else "python3"), "-m",
                             "threedgrut.export.scripts.ply_to_usd", str(ply_out),
                             "--output_file", str(usdz)],
                            cwd=repo, env=repo_env(repo))
                        export_lbl.set_content(f"✅ Fatto: **`{usdz}`** (+ PLY pulito accanto).")
                    except Exception as e:
                        export_lbl.set_content(f"✅ PLY pulito: `{ply_out}`. ❌ Conversione USDZ: {e}")
                threading.Thread(target=worker, daemon=True).start()

            ui.button("Esporta", icon="rocket", on_click=do_export).props("color=primary")

    ui.run(port=port, title="splat2sim lite", reload=False, show=False)


if __name__ in {"__main__", "__mp_main__"}:
    main()
