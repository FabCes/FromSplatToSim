"""Project configuration for splat2sim.

A project is a folder with a `project.yaml` describing inputs and options.
Every pipeline step reads/writes inside that folder, so a run is fully
reproducible and resumable.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml


@dataclass
class IngestConfig:
    video: Optional[str] = None          # path to input .mp4 (or image folder)
    target_frames: int = 300             # max frames extracted from the video
    min_sharpness: float = 40.0          # Laplacian-variance threshold (blur filter)
    lidar: Optional[str] = None          # optional .ply/.las/.pcd point cloud
    lidar_units_to_m: float = 1.0        # scale factor of lidar units to meters


@dataclass
class PosesConfig:
    engine: str = "colmap"               # colmap | glomap
    matcher: str = "sequential"          # sequential (video) | exhaustive (unordered)
    camera_model: str = "OPENCV"
    use_gpu: bool = True


@dataclass
class SplatConfig:
    engine: str = "3dgrut"               # visual reconstruction backend
    config_name: str = "apps/colmap_3dgut.yaml"
    iterations: int = 30000
    export_usdz: bool = True
    extra_args: list[str] = field(default_factory=list)


@dataclass
class GeoConfig:
    engine: str = "2dgs"                 # 2dgs | pgsr | gaussians | none
    # "gaussians": build the mesh directly from the trained splat (voxel
    # density + marching cubes) — no second GPU training pass required.
    iterations: int = 30000
    tsdf_voxel: float = 0.02             # scene units
    depth_trunc: float = 8.0             # scene units
    grid_res: int = 300                  # gaussians engine: voxels along diagonal
    iso: float = 0.35                    # gaussians engine: density threshold
    extra_args: list[str] = field(default_factory=list)


@dataclass
class CropBox:
    """Axis-aligned region of interest, in scene coordinates (meters).

    Applied consistently to BOTH the splat (gaussian filtering) and the
    mesh (clipping), so the visual and physics layers always match.
    """
    center: tuple[float, float, float] = (0.0, 0.0, 0.0)
    size: tuple[float, float, float] = (20.0, 20.0, 10.0)
    enabled: bool = False


@dataclass
class CleanupConfig:
    crop: CropBox = field(default_factory=CropBox)
    # splat cleanup
    min_opacity: float = 0.05            # drop nearly transparent gaussians
    outlier_neighbors: int = 12          # statistical floater removal
    outlier_std: float = 2.0
    max_scale: float = 1.0               # drop gaussians larger than this (m); huge blobs = sky/floaters
    # mesh cleanup
    keep_components: int = 0             # 0 = keep all above min_component_faces
    min_component_faces: int = 500
    target_faces: int = 200000           # decimation target for the collider
    fill_holes: bool = True
    # component artifact filters (structure collider)
    min_extent: float = 0.0              # drop components smaller than this bbox diagonal
    max_hover: float = 0.0               # drop small components floating above ground
    hover_max_extent: float = 0.0        # floating filter only applies below this size


@dataclass
class GroundConfig:
    """Optional dedicated terrain layer: hole-free heightfield collider."""
    enabled: bool = False
    grid_res: int = 120
    percentile: float = 5.0
    smooth: float = 4.0                  # aggressive smoothing (sigma in cells)
    object_size: float = 0.0             # flatten localized bumps up to this footprint
    robust_band: float = 0.0             # reject misaligned patches beyond this height band


@dataclass
class ExportConfig:
    asset_name: str = "scene"
    mode: str = "static"                 # static (env) | dynamic (rigid-body object)
    scale_to_meters: float = 1.0         # manual metric scale (COLMAP scenes are scale-free!)
    z_up_rotation_deg: tuple[float, float, float] = (0.0, 0.0, 0.0)
    semantic_label: Optional[str] = None # e.g. "ground", "obstacle"
    package_usdz: bool = True


@dataclass
class ProjectConfig:
    name: str = "my_scene"
    ingest: IngestConfig = field(default_factory=IngestConfig)
    poses: PosesConfig = field(default_factory=PosesConfig)
    splat: SplatConfig = field(default_factory=SplatConfig)
    geo: GeoConfig = field(default_factory=GeoConfig)
    cleanup: CleanupConfig = field(default_factory=CleanupConfig)
    ground: GroundConfig = field(default_factory=GroundConfig)
    export: ExportConfig = field(default_factory=ExportConfig)

    # ------------------------------------------------------------------ io
    def save(self, path: Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(dataclasses.asdict(self), sort_keys=False))

    @classmethod
    def load(cls, path: Path) -> "ProjectConfig":
        data = yaml.safe_load(Path(path).read_text()) or {}
        return _from_dict(cls, data)


def _from_dict(cls, data):
    """Recursively build (nested) dataclasses from a plain dict."""
    if not dataclasses.is_dataclass(cls):
        return data
    kwargs = {}
    for f in dataclasses.fields(cls):
        if f.name not in data:
            continue
        v = data[f.name]
        if dataclasses.is_dataclass(f.type) or (isinstance(f.type, str)):
            # resolve string annotations
            ftype = f.type if not isinstance(f.type, str) else globals().get(f.type, None)
        else:
            ftype = f.type
        if ftype is not None and dataclasses.is_dataclass(ftype) and isinstance(v, dict):
            kwargs[f.name] = _from_dict(ftype, v)
        elif isinstance(v, list) and f.name in ("center", "size", "z_up_rotation_deg"):
            kwargs[f.name] = tuple(v)
        else:
            kwargs[f.name] = v
    return cls(**kwargs)


# ---------------------------------------------------------------- presets
def preset(kind: str) -> ProjectConfig:
    """Built-in presets: 'outdoor' (default) and 'object'."""
    cfg = ProjectConfig()
    if kind == "object":
        cfg.ingest.target_frames = 150
        cfg.poses.matcher = "exhaustive"
        cfg.geo.tsdf_voxel = 0.005
        cfg.geo.depth_trunc = 3.0
        cfg.cleanup.crop = CropBox(center=(0, 0, 0), size=(2, 2, 2), enabled=True)
        cfg.cleanup.target_faces = 50000
        cfg.export.mode = "dynamic"
    elif kind == "outdoor":
        cfg.cleanup.max_scale = 2.0
        cfg.export.semantic_label = "ground"
    return cfg
